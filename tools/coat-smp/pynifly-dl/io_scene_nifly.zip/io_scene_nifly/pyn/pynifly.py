"""
Wrapper around nifly to provide python-friendly access to nifs

Check the first test to see basic functionality exercised.
"""

import os
from enum import Enum
import re
import logging
from ctypes import *
from typing import ValuesView, List 
import xml.etree.ElementTree as xml
from pathlib import Path
from .niflytools import *
from .nifdefs import *
from . import xmltools
from .niflydll import nifly, nifly_path
from .nifconstants import BSXFlagsValues


# Set up logging
log = logging.getLogger("pynifly")


# --- Helper Routines --- #

def check_return(func, *args, **kwargs):
    NifFile.clear_log()
    errval = 0
    try:
        errval = func(*args, **kwargs)
    except Exception as e:
        raise Exception(f"Error calling nifly {func.__name__}: {e}")
    if func.restype is None:
        if NifFile.message_log():
            raise Exception(f"Error calling nifly {func.__name__}: " + (NifFile.message_log()))
    elif errval != 0:
        raise Exception(f"Error calling nifly {func.__name__}: "
            + (NifFile.message_log() if NifFile.message_log() else "(no message)"))


def check_msg(func, *args, **kwargs):
    nifly.clearMessageLog()
    try:
        retval = func(*args, **kwargs)
        if NifFile.message_log():
            raise Exception(f"Error calling nifly {func.__name__}: " + (NifFile.message_log()))
    except Exception as e:
        raise Exception(f"Error calling nifly {func.__name__}: {e}") from e
    return retval


def check_id(func, *args, **kwargs):
    nifly.clearMessageLog()
    try:
        retval = func(*args, **kwargs)
        if (retval or 0xFFFFFFFF) == NODEID_NONE:
            raise Exception(f"Error calling nifly {func.__name__}: " + (NifFile.message_log()))
    except Exception as e:
        raise Exception(f"Error calling nifly {func.__name__}: {NifFile.message_log()}") from e
    return retval


def get_weights_by_bone(weights_by_vert, used_groups):
    """Given a list of weights 1-1 with vertices, return weights organized by bone. 
        weights_by_vert = [dict[group-name: weight], ...] 1-1 with verts
        Result: {group_name: [(vert_index, weight), ...], ...}
        Result contains only groups with non-zero weights, only groups that are in the 
        used-groups list, and only the 4 heaviest weights, which are normalized to add up to 1.
    """
    result = {}
    #Get weights by group
    for vert_index, vert_weights in enumerate(weights_by_vert):
        weight_pairs = [(w, nm) for nm, w in vert_weights.items() if w > 0.00005 and nm in used_groups]
        weight_pairs.sort()
        weight_pairs.reverse()
        sum_weights = sum(vw for vw, nm in weight_pairs[0:4])
        for wgt, nm in weight_pairs[0:4]:
            if nm not in result:
                result[nm] = []
            result[nm].append((vert_index, wgt/sum_weights))
            
    return result


def get_weights_by_vertex(verts, weights_by_bone):
    """Given a list of weights by bone, return a list 1:1 with vertices"""
    wbv = [None] * len(verts)
    for i in range(0, len(verts)):
        wbv[i] = {}
        
    for this_bone, this_weightlist in weights_by_bone.items():
        for weight_pair in this_weightlist:
            this_vert, this_weight = weight_pair
            wbv[this_vert][this_bone] = this_weight
    return wbv


class Partition:
    def __init__(self, part_id=0, namedict=None, name=None):
        self.id = part_id
        self._name = name
        self.namedict = namedict

    @property
    def name(self):
        if self._name:
            return self._name
        else:
            return f"{self.__class__.__name__} #{self.id}"

    @name.setter
    def name(self, val):
        if val:
            self._name = val

    def __eq__(self, other):
        return self.name == other.name

    def __lt__(self, other):
        return self.name < other.name

    def __le__(self, other):
        return self.name <= other.name

    def __gt__(self, other):
        return self.name > other.name

    def __ge__(self, other):
        return self.name >= other.name

class SkyPartition(Partition):
    skymatch = re.compile(r'SBP_([0-9]+)_\w+')

    def __init__(self, part_id=0, flags=0, namedict=None, name=None):
        super().__init__(part_id, namedict, name)
        self.flags = flags
        if not self._name:
            bp = namedict.part_by_id(part_id)
            if bp:
                self._name = bp.name
            else:
                self._name = f"SBP_{part_id}_UNKNOWN"

    @classmethod
    def name_match(cls, name):
        m = SkyPartition.skymatch.match(name)
        if m:
            return int(m.group(1))
        else:
            return -1

class FO4Segment(Partition):
    fo4segmatch = re.compile(r'FO4\w+ \#*([0-9]+)\Z')
    fo4segmatch1 = re.compile(r'FO4 Seg +([0-9]+)\Z')

    def __init__(self, part_id=0, index=0, subsegments=0, namedict=fo4Dict, name=None):
        super().__init__(part_id, namedict=namedict, name=name)
        self.index = index
        self.subseg_count = subsegments
        self.subsegments = []

    @property
    def name(self):
        """ FO4 segments don't have proper names. Build a fake name from the ID
            """
        if self._name:
            return self._name
        else:
            return "FO4 Seg " + '{:0>3d}'.format(self.index)

    @classmethod
    def name_match(cls, name):
        m = FO4Segment.fo4segmatch1.match(name)
        if m:
            return int(m.group(1))

        m = FO4Segment.fo4segmatch.match(name)
        if m:
            return int(m.group(1))
        else:
            return -1

class FO4Subsegment(FO4Segment):
    fo4subsegm1 = re.compile(r'(FO4 Seg [0-9]+) \| ([^\|]+)( \| (.+))?\Z')
    fo4subsegm = re.compile(r'\AFO4 *.*')
    fo4bpm = re.compile(r'\AFO4 *(\d+) - ')

    def __init__(self, part_id, user_slot, material=-1, parent=None, namedict=fo4Dict, name=None):
        """
        part_id = unique id used inside the nif
        user_slot = user index
        material = bone ID
        parent = parent segment
        namedict = dictionary to use
        name = name for the subsegment. If not provided, will be constructed.
        """
        super().__init__(part_id, user_slot, 0, namedict, name)
        self.user_slot = user_slot
        self.material = material
        # Slice-plane positions along the dismember bone (the "cut offsets" in
        # BSGeometryPerSegmentSharedData). Empty on most subsegments; only the
        # bearer of each material carries a non-empty list (0-8 floats).
        self.cut_offsets = []
        if name:
            self._name = name
        else:
            bp_name = namedict.part_by_id(user_slot)
            if not bp_name:
                if user_slot == 0:
                    bp_name = '{:0>3d}'.format(len(parent.subsegments))
                else:
                    bp_name = '{:0>3d}'.format(user_slot)

            mat_name = namedict.dismem_by_id(material)
            if not mat_name:
                mat_name = ""
                if material != 0xffffffff:
                    mat_name = '0x{:0>8x}'.format(material)
            if len(mat_name) > 0:
                mat_name = " | " + mat_name

            self._name = f"{parent.name} | {bp_name}{mat_name}"

        self.parent = parent
        parent.subsegments.append(self)

    @property
    def parent_name(self):
        self.parent.name

    @classmethod
    def name_match(cls, name):
        """ Determine whether given string is a valid FO4Subsegment name. Ignore any numeral after a hash. Returned parent name comes from built-in name structure.
            Returns: name of parent, ID (body part # or dismember hash), dismember hash of parent
        """
        mat = 0
        m = FO4Subsegment.fo4subsegm1.match(name)
        if m:
            id = 0
            mat = -1
            try:
                if len(m.groups()) >= 2:
                    if m[2] in fo4Dict.parts:
                        id = fo4Dict.parts[m[2]]
                    else:
                        id = int(m[2])
                if len(m.groups()) >= 4 and m[4]:
                    if m[4] in fo4Dict.dismem:
                        mat = fo4Dict.dismem[m[4]]
                    else:
                        mat = int(m[4], 0)
            except:
                log.error(f"Cannot parse segment name: {name}")
            return(m[1], id, mat)

        m = FO4Subsegment.fo4bpm.match(name)
        if m:
            subseg_id = int(m.group(1))
            parent_name = ''
            return (parent_name, subseg_id, mat)
        
        m = FO4Subsegment.fo4subsegm.match(name)
        if m:
            subseg_id = 0
            return ('', subseg_id, mat)
        else:
            return ("", -1, mat)

# --- NiObject -- #
class NiObject:
    """ Represents any block in a nif file. """
    
    # These are the types of blocks we can create from an ID. {classname: class, ...}
    block_types = {}
    # This is an array indexed by buffer type, containing the associated classes.
    buffer_types = [None] * PynBufferTypes.COUNT

    # Buffer used to pass properties across the DLL layer. Overridden by subtypes.
    buffer_type = -1
    
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        self._handle = handle
        self._controller = None
        self.file:NifFile = file
        self.id = id
        if handle is None and id != NODEID_NONE and file is not None:
            self._handle = check_msg(nifly.getNodeByID,file._handle, id)
        if self.id == NODEID_NONE and handle is not None and file is not None:
            self.id = check_msg(nifly.getBlockID, self.file._handle, self._handle)
        self._parent = parent
        if properties:
            self._properties = properties
        else:
            self._properties = None
        self._blockname = None
    
    @property
    def blockname(self):
        if self._blockname == None:
            if self.id == NODEID_NONE:
                self._blockname = self.__class__.__name__
            else:
                buf = create_string_buffer(128)
                nifly.getBlockname(self.file._handle, self.id, buf, 128)
                self._blockname = buf.value.decode('utf-8')
        return self._blockname
    
    @property
    def properties(self):
        if not self._properties:
            self._properties = self.getbuf()
            if self.id != NODEID_NONE and self.file._handle:
                check_return(nifly.getBlock,
                    self.file._handle, 
                    self.id, 
                    byref(self._properties))
        return self._properties
    
    @properties.setter
    def properties(self, value):
        self._properties = value.copy()
        check_return(
            nifly.setBlock, self.file._handle, self.id, byref(self._properties))
        
    def write_properties(self):
        """ Write current properties to the nif file. """
        check_return(
            nifly.setBlock, self.file._handle, self.id, byref(self._properties))

    def register_subclasses():
        """Register all subclasses for easy finding."""
        subclasses = list(NiObject.__subclasses__())
        while subclasses:
            sc = subclasses.pop(0)
            NiObject.block_types[sc.__name__] = sc
            NiObject.buffer_types[sc.buffer_type] = sc
            subclasses = subclasses + sc.__subclasses__()

    @classmethod
    def _buftype_name(cls, buftype):
        """Given a buffer type id, return the associated class name."""
        return cls.buffer_types[buftype].__name__

    @classmethod
    def getbuf(cls, values=None):
        """To be overwritten by subclasses."""
        assert False, "getbuf should have been overwritten."


class NiObjectNET(NiObject):
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None, name=""):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._name = name
        self._controller = None
        self._bgdata = None
        self._strdata = None
        self._clothdata = None

        if self._handle:
            self.properties
            buflen = self.file.max_string_len
            buf = create_string_buffer(buflen)
            nifly.getNodeName(self._handle, buf, buflen)
            self._name = buf.value.decode('utf-8')
            if id == NODEID_NONE:
                self.id = nifly.getBlockID(self.file._handle, self._handle)

        self.file.register_node(self)


    @property
    def name(self):
        if self._name == None:
            namebuf = (c_char * self.file.max_string_len)()
            nifly.getString(
                self.file._handle, self._properties.nameID, self.file.max_string_len, namebuf)
            self._name = namebuf.value.decode('utf-8')
        return self._name
    
    @name.setter
    def name(self, value):
        if self.file: self.file.unregister_name(self)
        self._name = value
        if self.file: 
            if self.id != NODEID_NONE:
                self.properties.nameID = nifly.addString(
                    self.file._handle, value.encode('utf-8'))
                check_return(
                    nifly.setBlock, self.file._handle, self.id, byref(self._properties))

            self.file.register_node(self)
        

    @property
    def controller(self):
        if self._controller: return self._controller
        if self.properties.controllerID == NODEID_NONE: return None
        self._controller = self.file.read_node(id=self.properties.controllerID, parent=self)
        return self._controller
    
    @controller.setter
    def controller(self, c):
        self._controller = c
        self.properties.controllerID = c.id
        nifly.setController(self.file._handle, self.id, c.id)
    

class NiProperty(NiObjectNET):
    pass


# --- Collisions --- #

class bhkShape(NiObject):
    @classmethod
    def New(cls, collisiontype=None, id=NODEID_NONE, file=None, parent=None, 
            properties=None):
        if properties:
            collisiontype = cls.buffer_types[properties.bufType].__name__
        elif not collisiontype:
            buf = create_string_buffer(128)
            nifly.getBlockname(file._handle, id, buf, 128)
            collisiontype = buf.value.decode('utf-8')
        try:
            if id == NODEID_NONE:
                id = nifly.addBlock(
                    file._handle, 
                    None, 
                    byref(properties), 
                    parent.id if parent else None)
            return file.read_node(
                id=id, parent=parent, properties=properties)
        except:
            return None


class bhkBoxShape(bhkShape):
    buffer_type = PynBufferTypes.bhkBoxShapeBufType
    needsTransform = True
    buffer_type = PynBufferTypes.bhkBoxShapeBufType

    @classmethod
    def getbuf(cls, values=None):
        return bhkBoxShapeProps(values)


class bhkCapsuleShape(bhkShape):
    buffer_type = PynBufferTypes.bhkCapsuleShapeBufType
    needsTransform = False

    @classmethod
    def getbuf(cls, values=None):
        return bhkCapsuleShapeProps(values)


class bhkSphereShape(bhkShape):
    buffer_type = PynBufferTypes.bhkSphereShapeBufType
    needsTransform = False

    @classmethod
    def getbuf(cls, values=None):
        return bhkSphereShapeBuf(values)


class bhkConvexVerticesShape(bhkShape):
    buffer_type = PynBufferTypes.bhkConvexVerticesShapeBufType
    needsTransform = False

    @classmethod
    def getbuf(cls, values=None):
        return bhkConvexVerticesShapeProps(values)

    def __init__(self, handle=None, id=NODEID_NONE, file=None, parent=None, properties=None):
        super().__init__(handle=handle, id=id, file=file, parent=parent, 
                         properties=properties)
        self._vertices = None
        self._normals = None

    @property
    def vertices(self):
        if not self._vertices:
            verts = (VECTOR4 * self.properties.vertsCount)()
            nifly.getCollShapeVerts(self.file._handle, 
                                            self.id, 
                                            verts, self.properties.vertsCount)
            self._vertices = [tuple(v) for v in verts]
        return self._vertices

    @property
    def normals(self):
        if not self._normals:
            norms = (VECTOR4 * self.properties.normalsCount)()
            nifly.getCollShapeNormals(self.file._handle, 
                                              self.id, 
                                              norms, self.properties.normalsCount)
            self._normals = [tuple(v) for v in norms]
        return self._normals


class bhkListShape(bhkShape):
    buffer_type = PynBufferTypes.bhkListShapeBufType
    needsTransform = False

    @classmethod
    def getbuf(cls, values=None):
        return bhkListShapeProps(values)

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._children = None

    @property
    def children(self):
        if not self._children:
            if self.properties.childCount == 0:
                self._children = []
            else:
                buf = (c_uint32 * self.properties.childCount)()
                nifly.getCollListShapeChildren(self.file._handle,
                                                       self.id,
                                                       buf, self.properties.childCount)
                self._children = []
                for idx in buf:
                    self._children.append(bhkShape.New(
                        id=idx, file=self.file, parent=self))
        
        return self._children

    def add_child(self, childnode):
        nifly.addCollListChild(
            self.file._handle, self.id, childnode.id)

    def add_shape(self, childprops, transform=None):
        child = bhkShape.New(file=self.file, properties=childprops, parent=self)
        if not self._children:
            self._children = []
        self._children.append(child)
        return child


class bhkConvexTransformShape(bhkShape):
    buffer_type = PynBufferTypes.bhkConvexTransformShapeBufType
    needsTransform = False
    
    @classmethod
    def getbuf(cls, values=None):
        return bhkConvexTransformShapeProps(values)

    def __init__(self, handle=None, id=NODEID_NONE, file=None, parent=None, 
                 properties=None, transform=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, 
                         parent=parent)
        if transform:
            self._set_transform(transform)
        self._child = None

    def _set_transform(self, xf):
        pt = self._props.transform
        for r in range(0, 4):
            for c in range(0, 4):
                pt[c*4+r] = xf[r][c]

    @property
    def transform(self):
        t = self.properties.transform
        return ((t[0][0], t[1][0], t[2][0], t[3][0]),
                (t[0][1], t[1][1], t[2][1], t[3][1]),
                (t[0][2], t[1][2], t[2][2], t[3][2]),
                (t[0][3], t[1][3], t[2][3], t[3][3]))

    def add_shape(self, childprops):
        child = bhkShape.New(file=self.file, properties=childprops, parent=self)
        self._child = child
        self.properties.shapeID = child.id
        return child

    @property
    def child(self):
        if self._child: return self._child
        self._child = bhkShape.New(id=self.properties.shapeID, file=self.file, parent=self)
        return self._child

    @child.setter
    def child(self, value):
        nifly.setCollConvexTransformShapeChild(self.file._handle,
                                                       self.id,
                                                       value.id)


class bhkMoppBvTreeShape(bhkShape):
    """MOPP BVH tree wrapping a child collision shape (bhkPackedNiTriStripsShape or bhkCompressedMeshShape)."""
    buffer_type = PynBufferTypes.bhkMoppBvTreeShapeBufType
    needsTransform = False

    @classmethod
    def getbuf(cls, values=None):
        return bhkMoppBvTreeShapeBuf(values)

    def __init__(self, handle=None, id=NODEID_NONE, file=None, parent=None, properties=None):
        super().__init__(handle=handle, id=id, file=file, parent=parent, properties=properties)
        self._child = None

    @property
    def child(self):
        if self._child is None:
            self._child = bhkShape.New(
                id=self.properties.shapeID, file=self.file, parent=self)
        return self._child

    @property
    def mopp_data(self):
        """Return (mopp_bytes, origin, scale) or (b'', (0,0,0), 0) if unavailable."""
        length = nifly.getCollMoppCodeLen(self.file._handle, self.id)
        if length <= 0:
            return b"", (0.0, 0.0, 0.0), 0.0
        origin_buf = (c_float * 3)()
        scale_buf = c_float()
        mopp_buf = (c_uint8 * length)()
        nifly.getCollMoppCode(self.file._handle, self.id,
                              origin_buf, byref(scale_buf), mopp_buf, length)
        origin = (origin_buf[0], origin_buf[1], origin_buf[2])
        return bytes(mopp_buf), origin, scale_buf.value

    @classmethod
    def Create(cls, file, verts, tris, game, radius=0.005, material=0,
               face_materials=None, parent=None):
        """Create a bhkMoppBvTreeShape with child shape and MOPP bytecode.

        Args:
            file: NifFile to add blocks to.
            verts: List of (x,y,z) in Havok space.
            tris: List of (i,j,k) triangle indices.
            game: Game name string ('SKYRIMSE', 'SKYRIM', etc.).
            radius: Collision radius.
            material: Default Havok material ID.
            face_materials: Optional per-face material uint32 list.
            parent: Parent block (bhkRigidBody).

        Returns:
            bhkMoppBvTreeShape instance.
        """
        from .mopp_compiler import compile_mopp

        # Create MOPP block (child shape ID will be set by child creation)
        buf = bhkMoppBvTreeShapeBuf()
        buf.shapeID = NODEID_NONE
        buf.buildType = 1  # placeholder; real value set in setCollMoppCode below
        mopp_id = check_msg(nifly.addBlock, file._handle, None, byref(buf),
                            parent.id if parent else NODEID_NONE)
        mopp_shape = cls(file=file, id=mopp_id, properties=buf, parent=parent)

        # Create the appropriate child shape
        if game in ('SKYRIM',):
            if face_materials and len(set(face_materials)) > 1:
                log.warning("Skyrim LE does not support per-chunk materials; "
                            "using default material")
            child = bhkPackedNiTriStripsShape.Create(
                file, verts, tris, radius=radius, material=material,
                parent=mopp_shape)
            output_ids = list(range(len(tris)))
        else:
            # For SE, pass default material via face_materials if no per-face
            # materials are provided.
            if not face_materials and material != 0:
                face_materials = [material] * len(tris)
            child, output_ids = bhkCompressedMeshShape.Create(
                file, verts, tris, radius=radius,
                face_materials=face_materials, parent=mopp_shape,
                target=file.rootNode)

        # Compile MOPP bytecode
        mopp_bytes, origin, scale = compile_mopp(verts, tris, radius=radius,
                                                  output_ids=output_ids)

        # Set MOPP code on the block.
        # The 'scale' parameter is stored in offset.w and used by the engine
        # for MOPP spatial quantisation (254*256*256 / largest_dim).
        # buildType: 0=BUILT_WITH_CHUNK_SUBDIVISION,
        #            1=BUILT_WITHOUT_CHUNK_SUBDIVISION, 2=BUILD_NOT_SET
        # Vanilla always uses 1 (BUILT_WITHOUT_CHUNK_SUBDIVISION).
        origin_buf = (c_float * 3)(*origin)
        mopp_buf = (c_uint8 * len(mopp_bytes))(*mopp_bytes)
        check_msg(nifly.setCollMoppCode, file._handle, mopp_id,
                  origin_buf, c_float(scale), mopp_buf, len(mopp_bytes),
                  c_uint8(1))

        return mopp_shape


class bhkPackedNiTriStripsShape(bhkShape):
    """Packed triangle strips shape (Skyrim LE). Child of bhkMoppBvTreeShape."""
    buffer_type = PynBufferTypes.bhkPackedNiTriStripsShapeBufType
    needsTransform = False

    @classmethod
    def getbuf(cls, values=None):
        return bhkPackedNiTriStripsShapeBuf(values)

    def __init__(self, handle=None, id=NODEID_NONE, file=None, parent=None, properties=None):
        super().__init__(handle=handle, id=id, file=file, parent=parent, properties=properties)
        self._vertices = None
        self._triangles = None

    @classmethod
    def Create(cls, file, verts, tris, radius=0.005, material=0, parent=None):
        """Create a bhkPackedNiTriStripsShape with geometry data.

        Args:
            file: NifFile to add blocks to.
            verts: List of (x,y,z) in Havok space.
            tris: List of (i,j,k) triangle indices.
            radius: Collision radius.
            material: Havok material ID.
            parent: Parent block (bhkMoppBvTreeShape).

        Returns:
            bhkPackedNiTriStripsShape instance.
        """
        buf = bhkPackedNiTriStripsShapeBuf()
        buf.radius = radius
        buf.material = material
        shape_id = check_msg(nifly.addBlock, file._handle, None, byref(buf),
                             parent.id if parent else NODEID_NONE)

        if nifly.getCollPackedStripsDataID is not None:
            data_id = nifly.getCollPackedStripsDataID(file._handle, shape_id)

            if data_id >= 0 and nifly.setCollPackedStripsVerts is not None:
                # Set vertices
                flat_verts = (c_float * (len(verts) * 3))()
                for i, (x, y, z) in enumerate(verts):
                    flat_verts[i*3] = x
                    flat_verts[i*3+1] = y
                    flat_verts[i*3+2] = z
                check_msg(nifly.setCollPackedStripsVerts, file._handle,
                          data_id, flat_verts, len(verts))

            if data_id >= 0 and nifly.setCollPackedStripsTris is not None:
                # Set triangles (no normals for now)
                flat_tris = (c_uint16 * (len(tris) * 3))()
                for i, (a, b, c) in enumerate(tris):
                    flat_tris[i*3] = a
                    flat_tris[i*3+1] = b
                    flat_tris[i*3+2] = c
                check_msg(nifly.setCollPackedStripsTris, file._handle,
                          data_id, flat_tris, len(tris), None)

        shape = cls(file=file, id=shape_id, properties=buf, parent=parent)
        return shape

    @property
    def vertices(self):
        if self._vertices is None:
            if nifly.getCollPackedStripsShapeVerts is None:
                self._vertices = []
                return self._vertices
            count = nifly.getCollPackedStripsShapeVerts(
                self.file._handle, self.properties.dataID, None, 0)
            if count > 0:
                buf = (c_float * (count * 3))()
                nifly.getCollPackedStripsShapeVerts(
                    self.file._handle, self.properties.dataID, buf, count)
                self._vertices = [(buf[i*3], buf[i*3+1], buf[i*3+2])
                                  for i in range(count)]
            else:
                self._vertices = []
        return self._vertices

    @property
    def triangles(self):
        if self._triangles is None:
            if nifly.getCollPackedStripsShapeTris is None:
                self._triangles = []
                return self._triangles
            count = nifly.getCollPackedStripsShapeTris(
                self.file._handle, self.properties.dataID, None, 0)
            if count > 0:
                buf = (c_uint16 * (count * 3))()
                nifly.getCollPackedStripsShapeTris(
                    self.file._handle, self.properties.dataID, buf, count)
                self._triangles = [(buf[i*3], buf[i*3+1], buf[i*3+2])
                                   for i in range(count)]
            else:
                self._triangles = []
        return self._triangles


class bhkCompressedMeshShape(bhkShape):
    """Compressed mesh shape (Skyrim SE). Child of bhkMoppBvTreeShape."""
    buffer_type = PynBufferTypes.bhkCompressedMeshShapeBufType
    needsTransform = False

    @classmethod
    def getbuf(cls, values=None):
        return bhkCompressedMeshShapeBuf(values)

    def __init__(self, handle=None, id=NODEID_NONE, file=None, parent=None, properties=None):
        super().__init__(handle=handle, id=id, file=file, parent=parent, properties=properties)
        self._vertices = None
        self._triangles = None

    @classmethod
    def Create(cls, file, verts, tris, radius=0.005, face_materials=None,
               parent=None, target=None):
        """Create a bhkCompressedMeshShape with chunked geometry data.

        Segments the mesh into chunks (<=255 verts, <=255 tris each),
        quantizes vertices, builds triangle strips, and creates all DLL blocks.

        Args:
            file: NifFile to add blocks to.
            verts: List of (x,y,z) in Havok space.
            tris: List of (i,j,k) triangle indices.
            radius: Collision radius.
            face_materials: Optional per-face HavokMaterial uint32 list.
            parent: Parent block (bhkMoppBvTreeShape).
            target: NiNode this collision belongs to. Defaults to file.rootNode.
                Vanilla SE nifs set Target to the root node.

        Returns:
            (bhkCompressedMeshShape, output_ids)
            output_ids: List of MOPP output IDs per input triangle.
        """
        from .mesh_segment import segment_mesh
        from .tri_strip import stripify

        # Build materials array from per-face materials
        # materials_list[i] = (havok_material, layer) — chunks reference by index
        if face_materials and any(m != 0 for m in face_materials):
            unique_mats = sorted(set(face_materials))
            mat_to_idx = {m: i for i, m in enumerate(unique_mats)}
        else:
            unique_mats = [0]  # single default material
            mat_to_idx = {0: 0}
            face_materials = None  # treat as uniform

        # Segment mesh into chunks — split by material first if multi-material
        if face_materials and len(unique_mats) > 1:
            # Group faces by material, then segment each material group
            all_groups = segment_mesh(verts, tris)
            # Re-split any group that mixes materials
            groups = []
            for group in all_groups:
                mats_in_group = set(face_materials[fi] for fi in group)
                if len(mats_in_group) <= 1:
                    groups.append(group)
                else:
                    for mat_val in mats_in_group:
                        sub = [fi for fi in group if face_materials[fi] == mat_val]
                        if sub:
                            groups.append(sub)
        else:
            groups = segment_mesh(verts, tris)

        # Vanilla Havok toolchain always uses fixed bit-field widths for
        # shape-key encoding, regardless of actual chunk sizes.  The engine
        # may assume these constants when decoding MOPP output IDs.
        bits_per_index = 17
        bits_per_w_index = 18
        mask_index = 0x1FFFF
        mask_w_index = 0x3FFFF

        # Set up buffer with data-block params and create shape + data blocks
        if target is None:
            target = file.rootNode
        buf = bhkCompressedMeshShapeBuf()
        buf.radius = radius
        buf.bitsPerIndex = bits_per_index
        buf.bitsPerWIndex = bits_per_w_index
        buf.maskIndex = mask_index
        buf.maskWIndex = mask_w_index
        buf.error = 0.001  # standard quantization tolerance for Skyrim SE
        buf.materialType = 1 if face_materials else 0
        buf.targetID = target.id if target else NODEID_NONE
        shape_id = check_msg(nifly.addBlock, file._handle, None, byref(buf),
                             parent.id if parent else NODEID_NONE)

        data_id = nifly.getCollCompressedMeshShapeDataID(file._handle, shape_id)
        if data_id < 0:
            shape = cls(file=file, id=shape_id, properties=buf, parent=parent)
            return shape, list(range(len(tris)))

        # Set materials array on the data block
        if len(unique_mats) > 0:
            mat_buf = (c_uint32 * len(unique_mats))(*unique_mats)
            check_msg(nifly.setCollCompressedMeshMaterials, file._handle,
                      data_id, mat_buf, None, len(unique_mats))

        # Build MOPP output IDs per input triangle
        output_ids = [0] * len(tris)

        # Set AABB
        all_x = [verts[i][0] for tri in tris for i in tri]
        all_y = [verts[i][1] for tri in tris for i in tri]
        all_z = [verts[i][2] for tri in tris for i in tri]
        bmin = (c_float * 3)(min(all_x), min(all_y), min(all_z))
        bmax = (c_float * 3)(max(all_x), max(all_y), max(all_z))
        check_msg(nifly.setCollCompressedMeshAABB, file._handle,
                  data_id, bmin, bmax)

        # Process each chunk
        for chunk_idx, face_group in enumerate(groups):
            chunk_tris = [tris[fi] for fi in face_group]

            # Collect unique vertices used by this chunk
            used_vert_set = set()
            for a, b, c in chunk_tris:
                used_vert_set.update((a, b, c))
            used_verts = sorted(used_vert_set)
            global_to_local = {g: l for l, g in enumerate(used_verts)}

            # Remap tris to local indices
            local_tris = [(global_to_local[a], global_to_local[b], global_to_local[c])
                          for a, b, c in chunk_tris]

            # Quantize vertices
            local_verts = [verts[g] for g in used_verts]
            if local_verts:
                tx = min(v[0] for v in local_verts)
                ty = min(v[1] for v in local_verts)
                tz = min(v[2] for v in local_verts)
            else:
                tx = ty = tz = 0.0

            # Check spatial extent fits in uint16 quantization (max 65.535 units)
            if local_verts:
                extent = max(
                    max(v[a] for v in local_verts) - min(v[a] for v in local_verts)
                    for a in range(3))
                if extent > 65.535:
                    log.warning(
                        f"Collision chunk {chunk_idx} spans {extent:.1f} Havok units "
                        f"(max 65.535); vertices will be clamped")

            quant_verts = []
            for x, y, z in local_verts:
                qx = max(0, min(65535, round((x - tx) * 1000.0)))
                qy = max(0, min(65535, round((y - ty) * 1000.0)))
                qz = max(0, min(65535, round((z - tz) * 1000.0)))
                quant_verts.extend([qx, qy, qz])

            # Build triangle strips
            strips, leftovers = stripify(local_tris)

            # Build indices array: strip indices first, then flat leftover indices
            indices = []
            strip_lengths = []
            for strip in strips:
                strip_lengths.append(len(strip))
                indices.extend(strip)
            for a, b, c in leftovers:
                indices.extend([a, b, c])

            # Add chunk via DLL
            translation_buf = (c_float * 4)(tx, ty, tz, 0.0)
            vert_buf = (c_uint16 * len(quant_verts))(*quant_verts)
            idx_buf = (c_uint16 * len(indices))(*indices)
            strip_buf = (c_uint16 * len(strip_lengths))(*strip_lengths) if strip_lengths else None
            # Determine material index for this chunk
            chunk_mat_idx = 0
            if face_materials:
                chunk_mat = face_materials[face_group[0]]
                chunk_mat_idx = mat_to_idx.get(chunk_mat, 0)
            check_msg(nifly.addCollCompressedMeshChunk,
                      file._handle, data_id,
                      translation_buf,
                      vert_buf, len(local_verts),
                      idx_buf, len(indices),
                      strip_buf, len(strip_lengths),
                      chunk_mat_idx)

            # Compute output IDs for MOPP.
            # chunk_index is 1-based (0 is for bigTris).
            # tri_in_chunk = INDEX POSITION within the indices array, NOT
            # the sequential triangle number.  For strip triangle k in a
            # strip starting at index offset strip_start: tri_in_chunk =
            # strip_start + k.  For flat triangle k: flat_start + k*3.
            # output = ((chunk_idx+1) << bits_per_w_index) | (winding << bits_per_index) | tri_in_chunk
            local_tri_sets = [frozenset(lt) for lt in local_tris]
            idx_pos = 0  # current position in the indices array
            for strip in strips:
                for k in range(len(strip) - 2):
                    winding = k & 1
                    tri_in_chunk = idx_pos + k
                    oid = ((chunk_idx + 1) << bits_per_w_index) | (winding << bits_per_index) | tri_in_chunk
                    if k % 2 == 0:
                        tri_set = frozenset((strip[k], strip[k+1], strip[k+2]))
                    else:
                        tri_set = frozenset((strip[k], strip[k+2], strip[k+1]))
                    for gi, fi in enumerate(face_group):
                        if local_tri_sets[gi] == tri_set:
                            output_ids[fi] = oid
                            local_tri_sets[gi] = None  # prevent double-match
                            break
                idx_pos += len(strip)
            # Flat triangles: each occupies 3 index positions
            for li, (a, b, c) in enumerate(leftovers):
                tri_in_chunk = idx_pos + li * 3
                oid = ((chunk_idx + 1) << bits_per_w_index) | (0 << bits_per_index) | tri_in_chunk
                leftover_set = frozenset((a, b, c))
                for gi, fi in enumerate(face_group):
                    if local_tri_sets[gi] == leftover_set:
                        output_ids[fi] = oid
                        local_tri_sets[gi] = None
                        break

        shape = cls(file=file, id=shape_id, properties=buf, parent=parent)
        return shape, output_ids

    @property
    def vertices(self):
        if self._vertices is None:
            count = nifly.getCollCompressedMeshShapeVerts(
                self.file._handle, self.properties.dataID, None, 0)
            if count > 0:
                buf = (c_float * (count * 3))()
                nifly.getCollCompressedMeshShapeVerts(
                    self.file._handle, self.properties.dataID, buf, count)
                self._vertices = [(buf[i*3], buf[i*3+1], buf[i*3+2])
                                  for i in range(count)]
            else:
                self._vertices = []
        return self._vertices

    @property
    def triangles(self):
        if self._triangles is None:
            count = nifly.getCollCompressedMeshShapeTris(
                self.file._handle, self.properties.dataID, None, 0)
            if count > 0:
                buf = (c_uint32 * (count * 3))()
                nifly.getCollCompressedMeshShapeTris(
                    self.file._handle, self.properties.dataID, buf, count)
                self._triangles = [(buf[i*3], buf[i*3+1], buf[i*3+2])
                                   for i in range(count)]
            else:
                self._triangles = []
        return self._triangles

    @property
    def material_ids(self):
        """Return per-triangle HavokMaterial uint32, same order as triangles."""
        count = nifly.getCollCompressedMeshTriMaterials(
            self.file._handle, self.properties.dataID, None, 0)
        if count <= 0:
            return []
        buf = (c_uint32 * count)()
        nifly.getCollCompressedMeshTriMaterials(
            self.file._handle, self.properties.dataID, buf, count)
        return list(buf)


class bhkConstraint(NiObject):
    buffer_type = PynBufferTypes.bhkRagdollConstraintBufType
    @classmethod
    def getbuf(cls, values=None):
        return bhkRagdollConstraintBuf(values)
    
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._entities = None

    @property
    def entities(self):
        if self._entities: return self._entities

        buf = (c_uint32 * self.properties.entityCount)()
        nifly.getRagdollEntities(
            self.file._handle, self.id, byref(buf), self.properties.entityCount)
        self._entities = []
        for constr_id in buf:
            self._entities.append(bhkWorldObject(file=self.file, id=constr_id, parent=self))
        
        return self._entities       


class bhkWorldObject(NiObject):
    @classmethod
    def getbuf(cls, values=None):
        assert False, "bhkWorldObject should never be instantiated directly."

    @classmethod
    def get_buffer(cls, bodytype, values=None):
        return NiObject.block_types[bodytype].getbuf(values=values)

    @classmethod
    def New(cls, objtype=None, id=NODEID_NONE, file=None, parent=None, properties=None):
        if properties:
            objtype = cls._buftype_name(properties.bufType)
        elif not objtype:
            buf = create_string_buffer(128)
            nifly.getBlockname(file._handle, id, buf, 128)
            objtype = buf.value.decode('utf-8')
        # try:
        if id == NODEID_NONE:
            id = nifly.addBlock(
                file._handle, 
                None, 
                byref(properties), 
                parent.id if parent else None)
        return file.read_node(id=id, parent=parent, properties=properties)

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._shape = None
        self._constraints = None

    @property 
    def constraints(self):
        if self._constraints: return self._constraints

        buf = (c_uint32 * self.properties.constraintCount)()
        nifly.getRigidBodyConstraints(
            self.file._handle, self.id, byref(buf), self.properties.constraintCount)
        self._constraints = []
        for constr_id in buf:
            self._constraints.append(bhkConstraint(file=self.file, id=constr_id, parent=self))
        
        return self._constraints

    @property
    def shape(self):
        if not self._shape:
            shape_index =self.properties.shapeID
            self._shape = bhkShape.New(
                id=shape_index, file=self.file, parent=self)
        return self._shape

    def add_shape(self, properties, vertices=None, normals=None, transform=None):
        """ Create collision shape 
            bhkConvexVerticesShape - vertices can be vectors of 3 points. Normals must be 
                vectors of 4 elements: x, y, z (setting direction), and w (length)
            bhkBoxShape & others - All data passed in through the properties
        """
        return self.file.add_shape(properties=properties, parent=self, 
                                   vertices=vertices, normals=normals, transform=transform)


class bhkRigidBody(bhkWorldObject):
    buffer_type = PynBufferTypes.bhkRigidBodyBufType

    @classmethod
    def getbuf(cls, values=None):
        return bhkRigidBodyProps(values)


class bhkRigidBodyT(bhkRigidBody):
    buffer_type = PynBufferTypes.bhkRigidBodyTBufType

    @classmethod
    def getbuf(cls, values=None):
        buf = bhkRigidBodyProps(values)
        buf.bufType = PynBufferTypes.bhkRigidBodyTBufType
        return buf


class bhkSimpleShapePhantom(bhkWorldObject):
    buffer_type = PynBufferTypes.bhkSimpleShapePhantomBufType

    @classmethod
    def getbuf(cls, values=None):
        return bhkSimpleShapePhantomBuf(values)


class NiCollisionObject(NiObject):
    """Represents various collision objects."""
    buffer_type = PynBufferTypes.NiCollisionObjectBufType

    @classmethod
    def getbuf(cls, values=None):
        return bhkNiCollisionObjectBuf(values)

    @classmethod
    def New(cls, 
            collisiontype=None, id=NODEID_NONE, file=None, parent=None, 
            properties=None):
        if properties:
            collisiontype = cls._buftype_name(properties.bufType)
        elif not collisiontype:
            buf = create_string_buffer(128)
            nifly.getBlockname(file._handle, id, buf, 128)
            collisiontype = buf.value.decode('utf-8')
        try:
            if id == NODEID_NONE:
                id = nifly.addBlock(
                    file._handle, 
                    None, 
                    byref(properties), 
                    parent.id if parent else None)
            return file.read_node(id=id, parent=parent, properties=properties)
        except:
            return None

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._body = None

    @property
    def flags(self):
        """ Return the collision object flags """
        return self.properties.flags

    @property
    def target(self):
        """ Return the node that is the target of the collision object """
        targ = nifly.getCollTarget(self.file._handle, self._handle)
        return self.file.nodeByHandle(targ)

    @property
    def body(self):
        """ Return the collision body object """
        if not self._body:
            if self.properties.bodyID != NODEID_NONE:
                self._body = bhkWorldObject.New(id=self.properties.bodyID, file=self.file, parent=self)
        return self._body

    def add_body(self, properties):
        """ Create a rigid body for this collision object """
        # rb_index = check_id(nifly.addBlock,
        #     self.file._handle, None, byref(properties), self.id)
        self._body = bhkWorldObject.New(file=self.file, parent=self, properties=properties)
        return self._body


class bhkPhysicsSystem(NiObject):
    """FO4 native-physics collision data — wraps a raw Havok packfile blob."""

    buffer_type = PynBufferTypes.bhkPhysicsSystemBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        # Skip getNodeByID — bhkPhysicsSystem data is accessed directly via block id.
        self._handle = handle
        self._controller = None
        self.file = file
        self.id = id
        self._parent = parent
        self._properties = properties
        self._blockname = None

    @classmethod
    def getbuf(cls, values=None):
        return bhkPhysicsSystemBuf(values)

    @property
    def data(self) -> bytes:
        """Return the raw Havok packfile bytes stored in this block.
        Returns b"" if the DLL functions are not yet available.
        """
        if nifly.getPhysicsSystemDataLen is None:
            return b""
        n = nifly.getPhysicsSystemDataLen(self.file._handle, self.id)
        if n <= 0:
            return b""
        buf = (c_char * n)()
        nifly.getPhysicsSystemData(self.file._handle, self.id, buf, n)
        return bytes(buf.raw)

    def write_data(self, data: bytes):
        """Write raw Havok packfile bytes into this block."""
        if nifly.setPhysicsSystemData is None:
            raise RuntimeError("setPhysicsSystemData not available in this DLL version")
        nifly.setPhysicsSystemData(self.file._handle, self.id, data, len(data))

    @classmethod
    def New(cls, file, data: bytes = None, shapes=None, verts=None, faces=None, parent=None):
        """Create a new bhkPhysicsSystem block in *file*.

        Pass one of:
          *data*   — raw Havok packfile bytes
          *shapes* — List[CollisionShape] from bhk_autounpack; packed via pack_shapes()
          *verts* + *faces* — raw geometry; packed via pack_convex_polytope()
        """
        if data is None:
            if shapes is not None:
                from .bhk_autopack import pack_shapes
                data = pack_shapes(shapes)
            else:
                from .bhk_autopack import pack_convex_polytope
                data = pack_convex_polytope(verts, faces)
        buf = bhkPhysicsSystemBuf()
        buf.dataSize = len(data)
        id = check_msg(nifly.addBlock,
                       file._handle, None, byref(buf),
                       parent.id if parent else NODEID_NONE)
        ps = cls(file=file, id=id, properties=buf, parent=parent)
        ps.write_data(data)
        return ps

    @property
    def geometry(self):
        """Return a list of CollisionShape objects decoded from the Havok packfile.

        Each CollisionShape has:
          shape_type: str — "polytope", "compressed_mesh", or "compound"
          name: str — suggested Blender object name
          transform: Optional[BodyTransform] — body position/rotation (None = identity)
          verts: List[Vert3] — (x, y, z) float tuples in Havok space
          faces: List[Face] — vertex index tuples (empty for compound shapes)
          convex_radius: float — Minkowski expansion radius (0.0 for mesh/compound)
          children: List[CollisionShape] — non-empty only for compound shapes
        """
        from .bhk_autounpack import parse_bytes
        return parse_bytes(self.data)


class bhkNPCollisionObject(NiCollisionObject):
    buffer_type = PynBufferTypes.bhkNPCollisionObjectBufType

    @classmethod
    def getbuf(cls, values=None):
        return bhkNPCollisionObjectBuf(values)

    @property
    def physics_system(self) -> bhkPhysicsSystem:
        """Return the bhkPhysicsSystem block referenced by this collision object."""
        data_id = self.properties.dataID
        if data_id == NODEID_NONE:
            return None
        return self.file.read_node(id=data_id)

    @property
    def body_id(self) -> int:
        """Return the body index within the physics system."""
        return self.properties.bodyID


class bhkNiCollisionObject(NiCollisionObject):
    buffer_type = PynBufferTypes.bhkNiCollisionObjectBufType

    @classmethod
    def getbuf(cls, values=None):
        return bhkNiCollisionObjectBuf(values)


class bhkCollisionObject(bhkNiCollisionObject):
    buffer_type = PynBufferTypes.bhkCollisionObjectBufType
    @classmethod
    def getbuf(cls, values=None):
        return bhkCollisionObjectBuf(values)


class bhkPCollisionObject(bhkNiCollisionObject):
    buffer_type = PynBufferTypes.bhkPCollisionObjectBufType
    @classmethod
    def getbuf(cls, values=None):
        return bhkNiCollisionObjectBuf(values)


class bhkSPCollisionObject(bhkPCollisionObject):
    buffer_type = PynBufferTypes.bhkSPCollisionObjectBufType
    @classmethod
    def getbuf(cls, values=None):
        return bhkSPCollisionObjectBuf(values)


class bhkBlendCollisionObject(bhkCollisionObject):
    buffer_type = PynBufferTypes.bhkBlendCollisionObjectBufType

    @classmethod
    def getbuf(cls, values=None):
        return bhkBlendCollisionObjectBuf(values)


class NiAVObject(NiObjectNET):
    def add_collision(self, body, flags=None, collision_type=None, body_id=None):
        if collision_type == PynBufferTypes.bhkSPCollisionObjectBufType:
            buf = bhkSPCollisionObjectBuf()
        elif collision_type == PynBufferTypes.bhkPCollisionObjectBufType:
            buf = bhkPCollisionObjectBuf()
        elif collision_type == PynBufferTypes.bhkNiCollisionObjectBufType:
            buf = bhkNiCollisionObjectBuf()
        elif collision_type == PynBufferTypes.bhkNPCollisionObjectBufType:
            buf = bhkNPCollisionObjectBuf()
        else:
            buf = bhkCollisionObjectBuf()
        if flags is not None: buf.flags = flags
        buf.targetID = self.id
        if collision_type == PynBufferTypes.bhkNPCollisionObjectBufType:
            # bodyID indexes the shared bhkPhysicsSystem's body array. It defaults
            # to a sentinel; leaving it unset makes the engine dereference a bad
            # index in bhkNPCollisionObject::CreateInstance and crash, so the
            # caller must pass the body this node uses.
            if body_id is not None:
                buf.bodyID = body_id
        else:
            buf.bodyID = NODEID_NONE
            if body: buf.bodyID = body.id
        new_coll = NiCollisionObject.New(file=self.file, properties=buf, parent=self)
        return new_coll
    

# --- NiNode --- #

class NiNode(NiAVObject):
    def __init__(self, handle=None, file=None, id=NODEID_NONE, parent=None, 
                 properties=None, name=""):
        super().__init__(handle=handle, file=file, id=id, parent=parent, 
                         properties=properties, name=name)
        
    buffer_type = PynBufferTypes.NiNodeBufType

    @classmethod
    def getbuf(cls, values=None):
        return NiNodeBuf(values)
    
    @property
    def blender_name(self):
        return self.file.dict.blender_name(self.name)

    @property
    def nif_name(self):
        return self.file.dict.nif_name(self.name)
    
    @property
    def transform(self):
        return self.properties.transform
    
    @transform.setter
    def transform(self, value):
        self.properties.transform = value

    @property
    def flags(self):
        return self.properties.flags

    @flags.setter
    def flags(self, value):
        self.properties.flags = value
        nifly.setNodeFlags(self._handle, value)

    @property
    def parent(self):
        if self._parent is None and self.file._handle is not None:
            parent_handle = nifly.getNodeParent(self.file._handle, self._handle)
            parent_id = nifly.getBlockID(self.file._handle, parent_handle)
            if parent_id != -1 and parent_id != NODEID_NONE:
                self._parent = self.file.read_node(id=parent_id)
        return self._parent

    @property
    def global_transform(self):
        if self.file._handle:
            buf = TransformBuf()
            nifly.getNodeTransformToGlobal(self.file._handle, self.name.encode('utf-8'), buf)
            return buf
        
        if not self.parent:
            return self.transform
        
        return self.parent.global_transform * self.transform
    
    
    @property
    def collision_object(self):
        if self.properties.collisionID != NODEID_NONE:
            return NiCollisionObject.New(id=self.properties.collisionID, file=self.file, parent=self)
        else:
            return None


    def _extra_data_id(self, blockname=None, name=None, target_index=0):
        """The nif block ID of the target extra data, or NODEID_NONE if the node has no
        extra data at that index. Distinguishes "no such block" from "block we can't read"."""
        if not self.file._handle: return NODEID_NONE

        return nifly.getExtraData(self.file._handle, self.id,
                                  blockname.encode('utf-8') if blockname else None,
                                  name.encode('utf-8') if name else None,
                                  target_index)


    def get_extra_data(self, blockname=None, name=None, target_index=0):
        """
        Search for the target extra data.
        blockname = the type of extra data to find. May be omitted.
        name = the name of the extra data to find. May be omitted.
        target_index = The index of the extra data, starting from 0.
        """
        ex_id = self._extra_data_id(blockname, name, target_index)
        if ex_id == NODEID_NONE:
            return None
        return self.file.read_node(id=ex_id, parent=self)


    def extra_data(self, blockname=None, name=None):
        """Convenience routine to walk all extra data on a node.

        A block whose TYPE PyNifly has no class for reads back as None -- read_node logs
        "Unknown block type". Skip it and keep walking: stopping there hides every block
        behind it. The Starfield head hits exactly that, with the unimplemented
        NiIntegersExtraData sitting ahead of the NiIntegerExtraData carrying MaterialID.
        """
        i = 0
        while True:
            ex_id = self._extra_data_id(blockname, name, i)
            if ex_id == NODEID_NONE:
                break
            ed = self.file.read_node(id=ex_id, parent=self)
            if ed:
                yield ed
            i += 1


class BSFaceGenNiNode(NiNode):
    pass

class BSFadeNode(NiNode):
    pass

class BSLeafAnimNode(NiNode):
    pass

class BSMasterParticleSystem(NiNode):
    pass

class BSMultiBoundNode(NiNode):
    buffer_type = PynBufferTypes.BSMultiBoundNodeBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSMultiBoundNodeBuf(values)

    @property
    def culling_mode(self):
        """BSCPCullingType (0=normal, 1=allpass, 2=allfail, 3=ignore, 4=force)."""
        return self.properties.cullingMode

    @culling_mode.setter
    def culling_mode(self, value):
        self.properties.cullingMode = value

    @property
    def multibound(self):
        """The BSMultiBound block referenced by this node, or None."""
        mbid = self.properties.multiBoundID
        if mbid == NODEID_NONE:
            return None
        return self.file.read_node(id=mbid)


class BSMultiBound(NiObject):
    buffer_type = PynBufferTypes.BSMultiBoundBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSMultiBoundBuf(values)

    @property
    def data(self):
        """The BSMultiBoundData (e.g. BSMultiBoundOBB) block, or None."""
        did = self.properties.dataID
        if did == NODEID_NONE:
            return None
        return self.file.read_node(id=did)


class BSMultiBoundOBB(NiObject):
    buffer_type = PynBufferTypes.BSMultiBoundOBBBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSMultiBoundOBBBuf(values)

    @property
    def center(self):
        return self.properties.center

    @property
    def size(self):
        return self.properties.size

    @property
    def rotation(self):
        return self.properties.rotation


class BSOrderedNode(NiNode):
    pass

class BSRangeNode(NiNode):
    pass

class BSTreeNode(NiNode):
    """Root node of a skinned tree. Carries Bones1/Bones2 node-pointer arrays
    (Bones1 is typically the armature root; Bones2 the remaining bones)."""

    def _get_bone_names(self, which):
        n = nifly.getBSTreeNodeBones(self.file._handle, self.id, which, None, 0)
        if n <= 0:
            return []
        buf = (c_uint32 * n)()
        nifly.getBSTreeNodeBones(self.file._handle, self.id, which, buf, n)
        names = []
        for bid in buf:
            node = self.file.read_node(id=bid)
            if node and node.name:
                names.append(node.name)
        return names

    @property
    def bones1(self):
        return self._get_bone_names(1)

    @property
    def bones2(self):
        return self._get_bone_names(2)

    def set_bone_ids(self, which, node_ids):
        """Set Bones1 (which=1) or Bones2 (which=2) to the given node ids."""
        arr = (c_uint32 * len(node_ids))(*node_ids)
        nifly.setBSTreeNodeBones(self.file._handle, self.id, which, arr, len(node_ids))


class BSValueNode(NiNode):
    buffer_type = PynBufferTypes.BSValueNodeBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSValueNodeBuf(values)


class BSWeakReferenceNode(NiNode):
    pass

class NiBillboardNode(NiNode):
    pass

class NiBone(NiNode):
    pass

class NiLODNode(NiNode):
    pass

class NiSortAdjustNode(NiNode):
    pass

class NiSwitchNode(NiNode):
    buffer_type = PynBufferTypes.NiSwitchNodeBufType

    @classmethod
    def getbuf(cls, values=None):
        return NiSwitchNodeBuf(values)

    @property
    def switch_flags(self):
        """NiSwitchFlags: 0=UPDATE_ONLY_ACTIVE_CHILD, 1=UPDATE_CONTROLLERS."""
        return self.properties.switchFlags

    @switch_flags.setter
    def switch_flags(self, value):
        self.properties.switchFlags = value

    @property
    def active_index(self):
        """Index of the active child."""
        return self.properties.switchActiveIndex

    @active_index.setter
    def active_index(self, value):
        self.properties.switchActiveIndex = value

class NiKeyFrameData(NiObject):
    pass


class LinearScalarKey:
    def __init__(self, buf:NiAnimKeyLinearBuf=None):
        if buf:
            self.time = buf.time
            self.value = buf.value
        self.addKey = nifly.addAnimKeyLinear

    def __eq__(self, other):
        return NearEqual(self.time, other.time) \
            and VNearEqual(self.value, other.value)
    
    def __str__(self): 
        return f"<LinearScalarKey>(time={self.time}, value={self.value:f})"

    def getbuf(self):
        buf = NiAnimKeyLinearBuf()
        buf.time = self.time
        buf.value = self.value
        return buf


class LinearVectorKey:
    def __init__(self, buf):
        self.time = buf.time
        self.value = [buf.value[0], buf.value[1], buf.value[2]]

    def __eq__(self, other):
        return NearEqual(self.time, other.time) \
            and VNearEqual(self.value, other.value)

    def __str__(self): 
        return f"<LinearVectorKey>(time={self.time}, value=[{self.value[0]:f}, {self.value[1]:f}, {self.value[2]:f}])"


class LinearQuatKey:
    def __init__(self, buf):
        self.time = buf.time
        self.value = [buf.value[0], buf.value[1], buf.value[2], buf.value[3]]

    def __eq__(self, other):
        return NearEqual(self.time, other.time) \
            and VNearEqual(self.value, other.value)

    def __str__(self): 
        return f"<LinearQuatKey>(time={self.time}, value=[{self.value[0]:f}, {self.value[1]:f}, {self.value[2]:f}, {self.value[3]:f}])"


class QuadScalarKey:

    def __init__(self, buf:NiAnimKeyFloatBuf=None):
        if buf:
            self.time = buf.time
            self.value = buf.value
            self.forward = buf.forward
            self.backward = buf.backward
        self.addKey = nifly.addAnimKeyQuadFloat

    def __eq__(self, other):
        return NearEqual(self.time, other.time) \
            and VNearEqual(self.value, other.value) \
            and VNearEqual(self.forward, other.forward) \
            and VNearEqual(self.backward, other.backward) 

    def __str__(self): 
        return f"<QuadScalarKey>(time={self.time}, value={self.value[:]}, forward={self.forward[:]}, backward={self.backward[:]})"
    
    def getbuf(self):
        buf = NiAnimKeyFloatBuf()
        buf.time = self.time
        buf.value = self.value
        buf.forward = self.forward
        buf.backward = self.backward
        return buf


class QuadVectorKey:
    time = 0.0
    value = []
    forward = 0.0
    backward = 0.0

    def __init__(self, buf:NiAnimKeyQuadTransBuf):
        self.time = buf.time
        self.value = buf.value[:]
        self.forward = buf.forward[:]
        self.backward = buf.backward[:]

    def __eq__(self, other):
        return NearEqual(self.time, other.time) \
            and VNearEqual(self.value, other.value) \
            and VNearEqual(self.forward, other.forward) \
            and VNearEqual(self.backward, other.backward) 

    def __str__(self): 
        return f"<QuadVectorKey>(time={self.time}, value={self.value[:]}, forward={self.forward[:]}, backward={self.backward[:]})"


class NiFloatData(NiObject):
    buffer_type = PynBufferTypes.NiFloatDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, 
                 properties=None, parent=None, keys=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        # self.keys = keys
        if self._handle == None and self.id == NODEID_NONE:
            self.id = nifly.addBlock(
                self.file._handle, 
                None, 
                byref(self.properties), 
                parent.id if parent else NODEID_NONE)
            if keys:
                for k in keys:
                    buf = k.getbuf()
                    k.addKey(self.file._handle, self.id, buf)
            self._handle = nifly.getNodeByID(self.file._handle, self.id)
            if parent: parent.data = self

    @property
    def keys(self):
        NifFile.clear_log()
        if self.id == NODEID_NONE: return None
        keys = []
        if self.properties.keys.interpolation in (
                NiKeyType.NO_INTERP, NiKeyType.LINEAR_KEY, NiKeyType.QUADRATIC_KEY):
            for frame in range(0, self.properties.keys.numKeys):
                # NO_INTERP keys are stored with bare time/value pairs (no tangents),
                # the same layout as LINEAR_KEY, so read them the same way.
                if self.properties.keys.interpolation in (
                        NiKeyType.NO_INTERP, NiKeyType.LINEAR_KEY):
                    buf = NiAnimKeyLinearBuf()
                    if nifly.getAnimKeyLinear(self.file._handle, self.id, frame, buf) != 0:
                        raise Exception(f"Error reading NiFloatDataKey: {NifFile.message_log()}")            
                    k = LinearScalarKey(buf)
                else:
                    buf = NiAnimKeyFloatBuf()
                    if nifly.getAnimKeyQuadFloat(self.file._handle, self.id, frame, buf) != 0:
                        raise Exception(f"Error reading NiFloatDataKey: {NifFile.message_log()}")            
                    k = QuadScalarKey(buf)
                keys.append(k)
        else:
            raise Exception(f"Unknown controller key type: {self.properties.keys.interpolation}")
        return keys

    def keys_add(self, k):
        """
        Write quadratic float key.
        """
        buf = NiAnimKeyFloatBuf()
        buf.time = k.time
        buf.value = k.value
        buf.forward = k.forward
        buf.backward = k.backward
        nifly.addAnimKeyQuadFloat(self.file._handle, self.id, buf)

    @classmethod
    def getbuf(cls, values=None):
        return NiFloatDataBuf(values)
        

class NiPosData(NiObject):
    buffer_type = PynBufferTypes.NiPosDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, 
                 properties=None, parent=None, keys=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._keys = None

    def _writequadkeys(self, keys):
        """
        Write quadratic float keys.
        keys = list of NiAnimKeyQuadTransBuf 
        """
        for k in keys:
            nifly.addAnimKeyQuadTrans(self.file._handle, self.id, k)

    @property
    def keys(self):
        if (self._keys is None) and (self.id != NODEID_NONE):
            NifFile.clear_log()
            if self.properties.keys.interpolation != NiKeyType.QUADRATIC_KEY:
                raise Exception(f"Unknown controller key type: {self.properties.keys.interpolation}")
            self._keys = []
            for frame in range(0, self.properties.keys.numKeys):
                buf = NiAnimKeyQuadTransBuf()
                nifly.getAnimKeyQuadTrans(self.file._handle, self.id, frame, buf) 
                self._keys.append(buf)
        return self._keys


    def add_key(self, key):
        """
        Write one key.
        """
        buf = NiAnimKeyQuadTransBuf()
        buf.time = key.time
        buf.value = key.value
        buf.forward = key.forward
        buf.backward = key.backward
        nifly.addAnimKeyQuadTrans(self.file._handle, self.id, buf)


    @classmethod
    def New(cls, file, interpolation, parent=None):
        p = NiPosDataBuf()
        p.keys.interpolation = interpolation

        pd = file.add_block(None, p, parent)

        return pd


    @classmethod
    def getbuf(cls, values=None):
        return NiPosDataBuf(values)
        

class NiTransformData(NiKeyFrameData):
    buffer_type = PynBufferTypes.NiTransformDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        
        self.xrotations = []
        self.yrotations = []
        self.zrotations = []
        self.qrotations = []
        self.translations = []
        self.scales = []

        if self.properties.rotationType == NiKeyType.XYZ_ROTATION_KEY:
            self._readxyzrot()
        elif self.properties.rotationType in [NiKeyType.LINEAR_KEY, NiKeyType.QUADRATIC_KEY]:
            self._readlinrot()

        for frame in range(0, self.properties.translations.numKeys):
            k = None
            if self.properties.translations.interpolation == NiKeyType.LINEAR_KEY:
                buf = NiAnimKeyLinearTransBuf()
                nifly.getAnimKeyLinearTrans(self.file._handle, self.id, frame, buf)
                k = LinearVectorKey(buf)
            elif self.properties.translations.interpolation == NiKeyType.QUADRATIC_KEY:
                buf = NiAnimKeyQuadTransBuf()
                nifly.getAnimKeyQuadTrans(self.file._handle, self.id, frame, buf)
                k = QuadVectorKey(buf)
            else:
                NifFile.log.warning(f"Found unknown key type: {self.properties.translations.interpolation}")
            if k: self.translations.append(k)

    @classmethod
    def getbuf(cls, values=None):
        return NiTransformDataBuf(values)
    
    @classmethod 
    def New(cls, file, 
            rotation_type=NiKeyType.LINEAR_KEY, 
            xyz_rotation_types=(NiKeyType.QUADRATIC_KEY, )*3,
            translate_type=NiKeyType.LINEAR_KEY,
            scale_type=NiKeyType.LINEAR_KEY,
            properties=None,
            parent=None):
        p:NiTransformDataBuf = properties
        if not p:
            p = NiTransformDataBuf()
            p.rotationType = rotation_type
            p.translations.interpolation = translate_type
            p.xRotations.interpolation = xyz_rotation_types[0]
            p.yRotations.interpolation = xyz_rotation_types[1]
            p.zRotations.interpolation = xyz_rotation_types[2]
            p.scales.interpolation = scale_type
        td = file.add_block(None, p, parent)
        return td
    
    def _readlinrot(self):
        """Read keys when the type is LINEAR_KEY or QUADRATIC_KEY. These are time, value
        pairs where the value is a quaternion. 
        """
        for frame in range(0, self.properties.rotationKeyCount):
            buf = NiAnimKeyLinearQuatBuf()
            nifly.getAnimKeyLinearQuat(self.file._handle, self.id, frame, buf)
            k = LinearQuatKey(buf)
            self.qrotations.append(k)

    def _readxyzrot(self):
        """Read keys when the type is XYZ_ROTATION_KEY. X, Y, and Z values are in separate
        lists and each can have a different key type. """
        for d, p, v in [('X', self.properties.xRotations, self.xrotations), 
                        ('Y', self.properties.yRotations, self.yrotations), 
                        ('Z', self.properties.zRotations, self.zrotations)]:
            for f in range(0, p.numKeys):
                k = self._readrotkey(d, f, p)
                v.append(k)

    def _readrotkey(self, d, frame, rots):
        dimension = c_char()
        dimension.value = d.encode('utf-8')
        if rots.interpolation == NiKeyType.QUADRATIC_KEY:
            buf = NiAnimKeyFloatBuf()
            nifly.getAnimKeyQuadXYZ(self.file._handle, self.id, dimension, frame, buf)
            k = QuadScalarKey(buf)
        elif rots.interpolation == NiKeyType.LINEAR_KEY:
            buf = NiAnimKeyLinearBuf()
            nifly.getAnimKeyLinearXYZ(self.file._handle, self.id, dimension, frame, buf)
            k = LinearScalarKey(buf)
        return k

    def add_translation_key(self, time, loc):
        """Add a key that does a translation. Keys must be added in time order."""
        buf = NiAnimKeyLinearTransBuf()
        buf.time = time
        buf.value = loc[:]
        nifly.addAnimKeyLinearTrans(self.file._handle, self.id, buf)

    def add_quad_translation_keys(self, keys):
        """
        Add tranlation keys with quadratic interpolation.
        keys = [NiAnimKeyQuadTransBuf, ...]
        """
        for k in keys:
            nifly.addAnimKeyQuadTrans(self.file._handle, self.id, k)

    def add_qrotation_key(self, time, q):
        """
        Add a key that does a rotation given as a quaternion, linear interpolation. 
        Keys must be added in time order.
        """
        buf = NiAnimKeyLinearQuatBuf()
        buf.time = time
        buf.value = q[:]
        nifly.addAnimKeyLinearQuat(self.file._handle, self.id, buf)

    def add_xyz_rotation_keys(self, dimension, key_list):
        """
        Add XYZ rotation keys.
        key_list = [NiAnimKeyFloatBuf, ...]
        """
        keytype = ''
        if dimension == "X": 
            keytype = self.properties.xRotations.interpolation
        elif dimension == "Y": 
            keytype = self.properties.yRotations.interpolation
        elif dimension == "Z": 
            keytype = self.properties.zRotations.interpolation
        elif dimension == "S": 
            keytype = self.properties.scales.interpolation
        
        d = c_char()
        d.value = dimension.encode('utf-8')
        if keytype == NiKeyType.QUADRATIC_KEY:
            for q in key_list:
                nifly.addAnimKeyQuadXYZ(
                    self.file._handle, self.id, d, byref(q.getbuf()))
        elif keytype in (NiKeyType.LINEAR_KEY, NiKeyType.NO_INTERP):
            # Linear keys are time/value only--no tangents.
            for q in key_list:
                nifly.addAnimKeyLinearXYZ(
                    self.file._handle, self.id, d, byref(q.getbuf()))
        elif key_list:
            # Don't drop keys silently: an empty channel is a broken animation and
            # much harder to spot than a loud failure here.
            raise NotImplementedError(
                f"Cannot write {len(key_list)} '{dimension}' rotation keys of type "
                f"{keytype!r}")


class NiInterpolator(NiObject):
    buffer_type = -1  # Abstract class

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._data = None

    @property
    def data(self):
        if self._data: return self._data
        if self.properties.dataID == NODEID_NONE: return None
        self._data = self.file.read_node(id=self.properties.dataID, parent=self)
        return self._data

    @data.setter
    def data(self, c):
        self._data = c
        self.properties.dataID = c.id

    def _default_import_func(interp, importer, nifnode):
        importer.warn(f"NYI: Import of interpolator {interp.id} {interp}")
    
    import_node = _default_import_func

    @classmethod
    def New(cls, file, data=None, parent=None):
        p = cls.getbuf()
        p.dataID = (data.id if data else NODEID_NONE)
        interp = file.add_block(None, p, parent)
        if data:
            interp._data = data
        return interp


class NiKeyBasedInterpolator(NiInterpolator):
    pass


class NiTransformInterpolator(NiKeyBasedInterpolator):
    buffer_type = PynBufferTypes.NiTransformInterpolatorBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._data = None

    @property
    def rotation(self):
        return self.properties.rotation
        
    @classmethod
    def getbuf(cls, values=None):
        return NiTransformInterpolatorBuf(values)
    
    @classmethod
    def New(cls, file, 
            translation=(0,0,0), rotation=(1,0,0,0), scale=1.0, 
            data_block=None, parent=None):
        p = NiTransformInterpolatorBuf()
        p.translation = translation
        p.rotation = rotation[:]
        p.scale = scale
        p.dataID = data_block.id if data_block else NODEID_NONE
        ti = file.add_block(None, p, parent)
        return ti

class BSRotAccumTransfInterpolator(NiTransformInterpolator):
    pass


class NiFloatInterpolator(NiKeyBasedInterpolator):
    buffer_type = PynBufferTypes.NiFloatInterpolatorBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        if self.id == NODEID_NONE and file and properties:
            self.id = nifly.addBlock(
                self.file._handle, 
                None, 
                byref(self.properties), 
                parent.id if parent else NODEID_NONE)
            self._handle = check_msg(nifly.getNodeByID,self.file._handle, self.id)
            if parent: parent.interpolator = self
        self._data = None
        
    @classmethod
    def getbuf(cls, values=None):
        return NiFloatInterpolatorBuf(values)

    @classmethod
    def New(cls, file, data=None, value=None, parent=None):
        p = cls.getbuf()
        p.dataID = (data.id if data else NODEID_NONE)
        p.floatValue = value if value is not None else 0.0
        interp = file.add_block(None, p, parent)
        if data:
            interp._data = data
        return interp


class NiBoolInterpolator(NiKeyBasedInterpolator):
    buffer_type = PynBufferTypes.NiBoolInterpolatorBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        if self.id == NODEID_NONE and file and properties:
            self.id = nifly.addBlock(
                self.file._handle, 
                None, 
                byref(self.properties), 
                parent.id if parent else NODEID_NONE)
            self._handle = check_msg(
                nifly.getNodeByID, self.file._handle, self.id)
            if parent: parent.interpolator = self
        self._data = None
        
    @classmethod
    def getbuf(cls, values=None):
        return NiBoolInterpolatorBuf(values)

    @classmethod
    def New(cls, file, data=None, value=None, parent=None):
        p = cls.getbuf()
        p.dataID = (data.id if data else NODEID_NONE)
        p.value = value if value is not None else 0
        interp = file.add_block(None, p, parent)
        if data:
            interp._data = data
        return interp


class NiPoint3Interpolator(NiKeyBasedInterpolator):
    buffer_type = PynBufferTypes.NiPoint3InterpolatorBufType

    @classmethod
    def getbuf(cls, values=None):
        return NiPoint3InterpolatorBuf(values)
    

class NiBlendInterpolator(NiObject):
    """Abstract class"""
    buffer_type = PynBufferTypes.NiBlendInterpolatorBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        if parent: parent.interpolator = self
        
    @classmethod
    def getbuf(cls, values=None):
        return NiBlendInterpolatorBuf(values)
    
    @classmethod
    def New(cls, file, parent=None):
        p = cls.getbuf()
        intp = file.add_block(None, p, parent)
        return intp
    
    def _default_creator(exporter):
        raise Exception("NYI: Export unknown blend interpolator")
    
    blend_interpolator = _default_creator
    

class NiBlendBoolInterpolator(NiBlendInterpolator):
    buffer_type = PynBufferTypes.NiBlendBoolInterpolatorBufType

    @property
    def value(self):
        return self.properties.boolValue
    
    @classmethod
    def getbuf(cls, values=None):
        b = NiBlendInterpolatorBuf(values)
        b.bufType = PynBufferTypes.NiBlendBoolInterpolatorBufType
        b.boolValue = 2 # Default as found in vanilla nifs
        return b

    
class NiBlendFloatInterpolator(NiBlendInterpolator):
    buffer_type = PynBufferTypes.NiBlendFloatInterpolatorBufType

    @property
    def value(self):
        return self.properties.floatValue
    
    @classmethod
    def getbuf(cls, values=None):
        b = NiBlendInterpolatorBuf(values)
        b.bufType = PynBufferTypes.NiBlendFloatInterpolatorBufType
        return b
    
    
class NiBlendPoint3Interpolator(NiBlendInterpolator):
    buffer_type = PynBufferTypes.NiBlendPoint3InterpolatorBufType

    @property
    def value(self):
        return self.properties.point3Value[:]
    
    @classmethod
    def getbuf(cls, values=None):
        b = NiBlendInterpolatorBuf(values)
        b.bufType = PynBufferTypes.NiBlendPoint3InterpolatorBufType
        return b
    
    
class NiBlendTransformInterpolator(NiBlendInterpolator):
    buffer_type = PynBufferTypes.NiBlendTransformInterpolatorBufType

    @property
    def value(self):
        return None
    
    @classmethod
    def getbuf(cls, values=None):
        b = NiBlendInterpolatorBuf(values)
        b.bufType = PynBufferTypes.NiBlendTransformInterpolatorBufType
        return b

    
class NiTimeController(NiObject):
    """
    Abstract class for time controllers. Keeping the chain of subclasses below because
    we'll likely need them eventually.
    """
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None,
                 target=None, interpolator=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._target = target
        if parent: parent.controller = self

    @property 
    def next_controller(self):
        if self.properties.nextControllerID == NODEID_NONE:
            return None
        else:
            return self.file.read_node(self.properties.nextControllerID)
        
    @property
    def target(self):
        if self._target: return self._target
        if self.properties.targetID == NODEID_NONE: return None
        self._target = self.file.read_node(id=self.properties.targetID)
        return self._target
    
    @property
    def is_cyclic(self):
        f = TimeControllerFlags()
        f.flags = self.properties.flags
        return f.cycle_type == CycleType.LOOP
    
    def _default_import_func(ctlr, importer, nifnode=None):
        raise Exception(f"NYI: Import of controller {ctlr.id} {ctlr}")
    
    def _default_fcurve_export(exporter, fcurves, target_obj):
        raise Exception(f"NYI: Export of fcurves on {target_obj.name}")
    
    import_node = _default_import_func
    fcurve_exporter = _default_fcurve_export


class NiInterpController(NiTimeController):
    pass


class NiSingleInterpController(NiInterpController):
    buffer_type = PynBufferTypes.NiSingleInterpControllerBufType

    def __init__(self, 
                 handle=None, file=None, id=NODEID_NONE, properties=None, parent=None,
                 target=None, interpolator=None):
        super().__init__(
            handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._target = target
        self._interpolator = interpolator
        
    @property
    def interpolator(self):
        if self._interpolator: return self._interpolator
        if self.properties.interpolatorID == NODEID_NONE: return None
        self._interpolator = self.file.read_node(
            id=self.properties.interpolatorID, parent=self)
        return self._interpolator
    
    @interpolator.setter
    def interpolator(self, c):
        self._interpolator = c
        self.properties.interpolatorID = c.id

    @property
    def target(self):
        if self._target: return self._target
        if self.properties.targetID == NODEID_NONE: return None
        self._target = self.file.read_node(id=self.properties.targetID)
        return self._target

    @classmethod
    def New(cls, file, 
            flags=108, 
            next_controller=None, 
            start_time=sys.float_info.max, stop_time=-sys.float_info.max, 
            frequency=1.0,
            phase=0,
            interpolator=None, 
            target=None, 
            var=0, 
            parent=None):
        p = cls.getbuf()
        p.flags = flags
        p.nextControllerID = (next_controller.id if next_controller else NODEID_NONE)
        p.startTime = start_time
        p.stopTime = stop_time
        p.frequency = frequency
        p.phase = phase
        if hasattr(p, 'controlledVariable'):
            # Only the ShaderProperty subclasses have this field
            p.controlledVariable = var
        if target: p.targetID = (target.id if target else NODEID_NONE)
        if interpolator: p.interpolatorID = (interpolator.id if interpolator else NODEID_NONE)
        c = file.add_block(None, p, parent)
        c._target = target
        c._interpolator = interpolator
        return c


class NiKeyframeController(NiSingleInterpController):
    pass


class NiTransformController(NiKeyframeController):
    buffer_type = PynBufferTypes.NiTransformControllerBufType

    def __init__(self, 
                 handle=None, file=None, id=NODEID_NONE, properties=None, parent=None,
                 target=None, interpolator=None):
        super().__init__(
            handle=handle, file=file, id=id, properties=properties, parent=parent,
            target=target, interpolator=interpolator)
        self._target = None
        self._properties = NiTransformControllerBuf()
        check_return(nifly.getBlock, self.file._handle, self.id, byref(self._properties))

    @classmethod
    def getbuf(cls, values=None):
        return NiTransformControllerBuf(values)
    

class NiMultiTargetTransformController(NiInterpController):
    buffer_type = PynBufferTypes.NiMultiTargetTransformControllerBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None,
                 target=None, interpolator=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent,
                 target=target, interpolator=interpolator)
        self._properties = NiMultiTargetTransformControllerBuf()
        check_return(nifly.getBlock, self.file._handle, self.id, byref(self._properties))

    @classmethod
    def getbuf(cls, values=None):
        return NiMultiTargetTransformControllerBuf(values)
    
    @classmethod
    def New(cls, file, flags, target, parent=None):
        p = NiMultiTargetTransformControllerBuf()
        p.flags = flags
        p.targetID = target.id
        tc = file.add_block(None, p, parent)
        tc._target = target
        return tc


class NiFloatInterpController(NiSingleInterpController):
    pass


class NiBoolInterpController(NiSingleInterpController):
    pass


class NiVisController(NiSingleInterpController):
    buffer_type = PynBufferTypes.NiVisControllerBufType

    @classmethod
    def getbuf(cls, values=None):
        return NiSingleInterpControllerBuf(
            values=values, buftype=PynBufferTypes.NiVisControllerBufType)




class BSEffectShaderPropertyColorController(NiFloatInterpController):
    buffer_type = PynBufferTypes.BSEffectShaderPropertyColorControllerBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None,
                 target=None, interpolator=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent,
                 target=target, interpolator=interpolator)
        if self.id == NODEID_NONE and file and properties: 
            self.id = nifly.addBlock(
                file._handle,
                None,
                byref(properties),
                parent.id if parent else None
            )
            if parent: parent.controller = self

    @classmethod
    def getbuf(cls, values=None):
        return BSEffectShaderPropertyColorControllerBuf(values)


class BSLightingShaderPropertyColorController(NiFloatInterpController):
    buffer_type = PynBufferTypes.BSLightingShaderPropertyColorControllerBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSLightingShaderPropertyColorControllerBuf(values)

    @classmethod
    def New(cls, file, flags, target, 
            start_time, stop_time,
            interpolator=None,
            next_controller=None,
            var=LightingShaderControlledColor.SPECULAR,
            parent=None):
        p = BSLightingShaderPropertyColorControllerBuf()
        p.flags = flags
        p.startTime = start_time
        p.stopTime = stop_time
        p.targetID = target.id
        p.nextControllerID = next_controller.id if next_controller else NODEID_NONE
        p.interpolatorID = interpolator.id if interpolator else NODEID_NONE
        p.typeOfControlledColor = var
        tc = file.add_block(None, p, parent)
        return tc


class BSEffectShaderPropertyFloatController(NiFloatInterpController):
    buffer_type = PynBufferTypes.BSEffectShaderPropertyFloatControllerBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None,
                 target=None, interpolator=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent,
                 target=target, interpolator=interpolator)
        if self.id == NODEID_NONE and file and properties: 
            self.id = nifly.addBlock(
                file._handle,
                None,
                byref(properties),
                parent.id if parent else None
            )
            if parent: parent.controller = self

    @classmethod
    def getbuf(cls, values=None):
        return BSEffectShaderPropertyFloatControllerBuf(values)


class BSLightingShaderPropertyFloatController(NiFloatInterpController):
    buffer_type = PynBufferTypes.BSLightingShaderPropertyFloatControllerBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSLightingShaderPropertyFloatControllerBuf(values)


class NiAlphaController(NiFloatInterpController):
    pass


class BSNiAlphaPropertyTestRefController(NiAlphaController):
    buffer_type = PynBufferTypes.BSNiAlphaPropertyTestRefControllerBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None,
                 target=None, interpolator=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent,
                 target=target, interpolator=interpolator)

    @classmethod
    def getbuf(cls, values=None):
        return BSNiAlphaPropertyTestRefControllerBuf(values)


class ControllerLink:
    buffer_type = PynBufferTypes.NiControllerLinkBufType


    def __init__(self, props:ControllerLinkBuf, parent):
        self.properties = props.copy()
        self.parent = parent
        self._controller = None
        self._nodename = None
        self._controller_type = None
        self._property_type = None
        self._interpolator = None

    @property
    def node_name(self):
        if self._nodename is None: 
            self._nodename = self.parent.file.get_string(self.properties.nodeName)
        return self._nodename
    
    @property
    def controller_type(self):
        if self._controller_type is None: 
            self._controller_type = self.parent.file.get_string(self.properties.ctrlType)
        return self._controller_type
    
    @property
    def property_type(self):
        if self._property_type is None: 
            self._property_type = self.parent.file.get_string(self.properties.propType)
        return self._property_type
    
    @property
    def interpolator(self):
        if self._interpolator: return self._interpolator
        self._interpolator = self.parent.file.read_node(
            id=self.properties.interpolatorID, parent=self.parent)
        return self._interpolator

    @property
    def controller(self):
        if self._controller: return self._controller
        if self.properties.controllerID == NODEID_NONE: return None
        self._controller = self.parent.file.read_node(id=self.properties.controllerID, parent=self)
        return self._controller
    
    @controller.setter
    def controller(self, node):
        self._controller = node
    
    @classmethod
    def New(cls, node_name, controller_type, file, properties=ControllerLinkBuf(), 
            parent=None):
        properties.nodeName = nifly.addString(
            file._handle, node_name.encode('utf-8'))
        properties.ctrlType = nifly.addString(
            file._handle, controller_type.encode('utf-8'))
        parent.add_controlled_block(
            node_name,
            properties.interpolatorID,
        )
        

class NiSequence(NiObject):
    buffer_type = PynBufferTypes.NiControllerSequenceBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._name = None
        self._controlled_blocks = None

    @property
    def name(self):
        if self._name: return self._name

        namebuf = (c_char * 128)()
        nifly.getString(
            self.file._handle, self.properties.nameID, 128, namebuf)
        self._name = namebuf.value.decode('utf-8')

        return self._name
    
    @property
    def controlled_blocks(self):
        if self._controlled_blocks is not None: return self._controlled_blocks
        
        self._controlled_blocks = []
        if self.properties.controlledBlocksCount > 0:
            buf = (ControllerLinkBuf * self.properties.controlledBlocksCount)()
            buf[0].bufSize = sizeof(ControllerLinkBuf) 
            buf[0].bufType = PynBufferTypes.NiControllerLinkBufType
            check_msg(
                nifly.getControlledBlocks,
                self.file._handle, 
                self.id, 
                self.properties.controlledBlocksCount, 
                byref(buf))
            for b in buf:
                self._controlled_blocks.append(ControllerLink(b, self))

        return self._controlled_blocks
    
    @property
    def accum_root_name(self):
        namebuf = (c_char * self.file.max_string_len)()
        check_msg(
            nifly.getString,
            self.file._handle, 
            self.properties.accumRootNameID, 
            self.file.max_string_len, 
            namebuf)
        return namebuf.value.decode('utf-8')

    def add_controlled_block(self,
                             name:str,
                             interpolator=None,
                             controller=None,
                             priority=0,
                             node_name=None,
                             #prop_type=None,
                             controller_type=None,
                             #ctrlr_id=None,
                             #interpolator_id=None,
                             ):
        buf = ControllerLinkBuf()
        buf.interpolatorID = interpolator.id if interpolator else NODEID_NONE
        buf.controllerID = controller.id if controller else NODEID_NONE
        buf.priority = priority
        buf.nodeName = NODEID_NONE
        buf.ctrlType = NODEID_NONE
        buf.ctrlID = NODEID_NONE
        buf.propType = NODEID_NONE
        if node_name is None:
            if name:
                node_name = name
            elif controller:
                if isinstance(controller.target, (NiShader, NiAlphaProperty,)):
                    node_name = controller.target.parent.name
                else:
                    node_name = controller.target.name
            else:
                node_name = ''
        buf.nodeName = nifly.addString(
            self.file._handle, node_name.encode('utf-8'))

        if controller and not isinstance(controller.target, NiNode): 
            prop_type = controller.target.blockname
            buf.propType = nifly.addString(
                self.file._handle, prop_type.encode('utf-8'))

            if controller_type is None:
                controller_type = controller.blockname

        if controller_type is None: 
            buf.ctrlType = NODEID_NONE
        else:
            buf.ctrlType = nifly.addString(
                self.file._handle, controller_type.encode('utf-8'))

        # Not adding the controller ID or interpoator ID string values because those can
        # change when nifly does cleanup on save. If this turns out to be a problem, we'll
        # have to set them after cleanup.
        buf.interpID = NODEID_NONE
        
        nifly.addBlock(self.file._handle, name.encode('utf-8'), byref(buf), self.id)
        if self._controlled_blocks is None: self._controlled_blocks = []
        self._controlled_blocks.append(ControllerLink(buf, self))

    def _default_import_func(self, importer):
        importer.warn(f"NYI: Import of NiSequence {self.id} {self.name}")
    
    import_node = _default_import_func


class NiExtraData(NiObject):
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._name = None

    @property
    def name(self):
        if self._name == None:
            namebuf = (c_char * self.file.max_string_len)()
            nifly.getString(
                self.file._handle, self.properties.nameID, self.file.max_string_len, namebuf)
            self._name = namebuf.value.decode('utf-8')
        return self._name
    
    @name.setter
    def name(self, value):
        self._name = value
        if self.file and self.id != NODEID_NONE:
            self.properties.nameID = nifly.addString(
                self.file._handle, value.encode('utf-8'))
            check_return(nifly.setBlock, self.file._handle, self.id, byref(self.properties))


class BSBound(NiExtraData):
    buffer_type = PynBufferTypes.BSBoundBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSBoundBuf(values)
    
    @property
    def center(self):
        return (self.properties.center[:])
    
    @center.setter
    def center(self, value):
        for i in range(0, 3):
            self.properties.center[i] = value[i]

    @property
    def half_extents(self):
        return (self.properties.halfExtents[:])
    
    @half_extents.setter
    def half_extents(self, value):
        for i in range(0, 3):
            self.properties.halfExtents[i] = value[i]

    @classmethod
    def New(cls, file, name='', center=(0, 0, 0), half_extents=(0, 0, 0), parent=None):
        p = BSBoundBuf()
        for i in range(0, 3):
            p.center[i] = center[i]
            p.halfExtents[i] = half_extents[i]
        return file.add_block(name, p, parent)


class BSFurnitureMarkerNode(NiExtraData):
    buffer_type = PynBufferTypes.BSFurnitureMarkerNodeBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._furniture_markers = None

    @classmethod
    def getbuf(cls, values=None):
        return BSFurnitureMarkerNodeBuf(values)
    
    @property
    def position_count(self):
        """
        Number of furniture marker positions.
        """
        return self.properties.position_count
    
    @property
    def furniture_markers(self) -> List[FurnitureMarkerDataBuf]:
        """
        Get furniture marker data as list of FurnitureMarkerDataBuf objects.
        """
        if self._furniture_markers is None:
            self._furniture_markers = []
            if self.properties.position_count > 0:
                # Get each furniture marker position individually
                for i in range(self.properties.position_count):
                    marker = FurnitureMarkerDataBuf()
                    result = nifly.getFurnitureMarkerPosition(
                        self.file._handle, self.id, i, byref(marker))
                    if result == 0:
                        # Create a copy of the marker data
                        marker_copy = FurnitureMarkerDataBuf()
                        marker_copy.offset[0] = marker.offset[0]
                        marker_copy.offset[1] = marker.offset[1]
                        marker_copy.offset[2] = marker.offset[2]
                        marker_copy.heading = marker.heading
                        marker_copy.animation_type = marker.animation_type
                        marker_copy.entry_points = marker.entry_points
                        self._furniture_markers.append(marker_copy)
        return self._furniture_markers
    
    @furniture_markers.setter
    def furniture_markers(self, value: List[FurnitureMarkerDataBuf]):
        """
        Set furniture marker data from list of FurnitureMarkerDataBuf objects.
        """
        self._furniture_markers = value
        self.properties.position_count = len(value)
        if self.file and self.id != NODEID_NONE:
            # Update the position count first
            check_return(nifly.setBlock, self.file._handle, self.id, byref(self.properties))
            
            # Add each furniture marker position
            if value:
                for marker in value:
                    marker_buf = FurnitureMarkerDataBuf()
                    marker_buf.offset[0] = float(marker.offset[0])
                    marker_buf.offset[1] = float(marker.offset[1])
                    marker_buf.offset[2] = float(marker.offset[2])
                    marker_buf.heading = float(marker.heading)
                    marker_buf.animation_type = int(marker.animation_type)
                    marker_buf.entry_points = int(marker.entry_points)
                    check_return(nifly.addFurnitureMarkerPosition, 
                                self.file._handle, self.id, byref(marker_buf))

    @classmethod
    def New(cls, file, name='', furniture_markers=None, parent=None):
        """
        Create a new BSFurnitureMarkerNode.
        
        Args:
            file: NifFile to add the node to
            name: Name for the node
            furniture_markers: List of FurnitureMarkerDataBuf objects
            parent: Parent node
        """
        if furniture_markers is None:
            furniture_markers = []
        p = BSFurnitureMarkerNodeBuf()
        fm_node = file.add_block(name, p, parent)
        
        # Add each furniture marker position directly
        if furniture_markers:
            for marker in furniture_markers:
                marker_buf = FurnitureMarkerDataBuf()
                marker_buf.offset[0] = float(marker.offset[0])
                marker_buf.offset[1] = float(marker.offset[1])
                marker_buf.offset[2] = float(marker.offset[2])
                marker_buf.heading = float(marker.heading)
                marker_buf.animation_type = int(marker.animation_type)
                marker_buf.entry_points = int(marker.entry_points)
                check_return(nifly.addFurnitureMarkerPosition, 
                            file._handle, fm_node.id, byref(marker_buf))
        return fm_node

    


class NiTextKeyExtraData(NiExtraData):
    buffer_type = PynBufferTypes.NiTextKeyExtraDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._keys = None

    @classmethod 
    def getbuf(cls, values=None):
        return NiTextKeyExtraDataBuf(values)

    @property 
    def keys(self):
        """
        Text keys returned as [(time, "value"), ...]
        """
        if self._keys is None:
            self._keys = []
            for i in range(0, self.properties.textKeyCount):
                buf = TextKeyBuf()
                valuebuf = create_string_buffer(256)
                nifly.getNiTextKey(
                    self.file._handle, self.id, i, byref(buf))
                n = nifly.getString(
                    self.file._handle, buf.valueID, 256, valuebuf)
                self._keys.append((buf.time, valuebuf.value.decode('utf-8'),))
        return self._keys
    
    def add_key(self, time, val):
        if self._keys is None: self._keys = []
        err = nifly.addTextKey(
            self.file._handle, self.id, time, val.encode('utf-8'))
        self._keys.append((time, val,))

    @classmethod
    def New(cls, file, name='', keys=(), parent=None):
        p = NiTextKeyExtraDataBuf()
        tk = file.add_block(name, p, parent)
        for t, v in keys:
            tk.add_key(t, v)
        return tk


class NiIntegerExtraData(NiExtraData):
    buffer_type = PynBufferTypes.NiIntegerExtraDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)

    @classmethod 
    def getbuf(cls, values=None):
        return NiIntegerExtraDataBuf(values)

    @property 
    def integer_data(self):
        """
        Integer value stored in this extra data block.
        """
        return self.properties.integerData
    
    @integer_data.setter
    def integer_data(self, value):
        """
        Set the integer value for this extra data block.
        """
        self.properties.integerData = value
        if self.file and self.id != NODEID_NONE:
            check_return(nifly.setBlock, self.file._handle, self.id, byref(self.properties))

    @classmethod
    def New(cls, file, name='', integer_value=0, parent=None):
        p = NiIntegerExtraDataBuf()
        p.integerData = integer_value
        return file.add_block(name, p, parent)


class NiIntegersExtraData(NiExtraData):
    """PLURAL -- a different block type from NiIntegerExtraData, holding an ARRAY of uint32.

    Starfield stores 'AnimationFlagExtra' this way: 273 of 373 vanilla shape nifs carry one, on the
    BSGeometry block. Values seen are hair 31, beards 47, eyes/teeth/tongue/eyebrows/tears 255,
    male head 32. Eyelashes carry no block at all -- the only part in human\\characterassets that
    doesn't -- so absence is legal and must not be "corrected" on export. It is authored data, not
    derived, so it round-trips verbatim rather than being recomputed on export."""
    buffer_type = PynBufferTypes.NiIntegersExtraDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)

    @classmethod
    def getbuf(cls, values=None):
        return NiIntegersExtraDataBuf(values)

    @property
    def values(self):
        """The block's integers, as a list."""
        n = self.properties.integerCount
        if not n:
            return []
        buf = (c_uint32 * n)()
        got = nifly.getNiIntegersExtraDataValues(self.file._handle, self.id, buf, n)
        return list(buf[:got])

    @values.setter
    def values(self, v):
        v = list(v)
        buf = (c_uint32 * len(v))(*v)
        nifly.setNiIntegersExtraDataValues(self.file._handle, self.id, buf, len(v))
        self.properties.integerCount = len(v)

    @classmethod
    def New(cls, file, name='', values=None, parent=None):
        values = list(values or [])
        p = NiIntegersExtraDataBuf()
        p.integerCount = len(values)
        block = file.add_block(name, p, parent)
        if values:
            block.values = values
        return block


class BSBehaviorGraphExtraData(NiExtraData):
    buffer_type = PynBufferTypes.BSBehaviorGraphExtraDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)

    @classmethod 
    def getbuf(cls, values=None):
        return BSBehaviorGraphExtraDataBuf(values)

    @property 
    def behavior_graph_file(self):
        """
        Behavior graph file path stored in this extra data block.
        """
        if self.properties.behaviorGraphFileID == NODEID_NONE:
            return ""
        namebuf = (c_char * self.file.max_string_len)()
        nifly.getString(
            self.file._handle, self.properties.behaviorGraphFileID, self.file.max_string_len, namebuf)
        return namebuf.value.decode('utf-8')
    
    @behavior_graph_file.setter
    def behavior_graph_file(self, value):
        """
        Set the behavior graph file path for this extra data block.
        """
        self.properties.behaviorGraphFileID = nifly.addString(
            self.file._handle, value.encode('utf-8'))
        if self.file and self.id != NODEID_NONE:
            check_return(nifly.setBlock, self.file._handle, self.id, byref(self.properties))

    @property 
    def controls_base_skeleton(self):
        """
        Boolean flag indicating whether this behavior graph controls the base skeleton.
        """
        return bool(self.properties.controlsBaseSkeleton)
    
    @controls_base_skeleton.setter
    def controls_base_skeleton(self, value):
        """
        Set the controls base skeleton flag for this extra data block.
        """
        self.properties.controlsBaseSkeleton = 1 if value else 0
        if self.file and self.id != NODEID_NONE:
            check_return(nifly.setBlock, self.file._handle, self.id, byref(self.properties))

    @classmethod
    def New(cls, file, name='', behavior_graph_file='', controls_base_skeleton=False, parent=None):
        p = BSBehaviorGraphExtraDataBuf()
        p.behaviorGraphFileID = nifly.addString(file._handle, behavior_graph_file.encode('utf-8'))
        p.controlsBaseSkeleton = 1 if controls_base_skeleton else 0
        return file.add_block(name, p, parent)


class BSDecalPlacementVectorExtraData(NiExtraData):
    buffer_type = PynBufferTypes.BSDecalPlacementVectorExtraDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)

    @classmethod
    def getbuf(cls, values=None):
        return BSDecalPlacementVectorExtraDataBuf(values)

    @property
    def vector_blocks(self):
        """Return list of vector blocks; each block is a list of (point, normal) tuples.

        point and normal are each (x, y, z) float tuples.
        """
        blocks = []
        for bi in range(self.properties.numVectorBlocks):
            count = c_uint16()
            nifly.getDecalVectorBlockCount(
                self.file._handle, self.id, bi, byref(count))
            vectors = []
            for vi in range(count.value):
                vbuf = DecalVectorBuf()
                nifly.getDecalVector(
                    self.file._handle, self.id, bi, vi, byref(vbuf))
                vectors.append((tuple(vbuf.point), tuple(vbuf.normal)))
            blocks.append(vectors)
        return blocks

    @classmethod
    def New(cls, file, name='', vector_blocks=None, parent=None):
        p = BSDecalPlacementVectorExtraDataBuf()
        p.numVectorBlocks = len(vector_blocks) if vector_blocks else 0
        node = file.add_block(name, p, parent)
        if vector_blocks:
            for bi, block in enumerate(vector_blocks):
                nifly.addDecalVectorBlock(file._handle, node.id)
                for point, normal in block:
                    vbuf = DecalVectorBuf()
                    vbuf.point[:] = point
                    vbuf.normal[:] = normal
                    nifly.addDecalVector(
                        file._handle, node.id, bi, byref(vbuf))
        return node


class NiStringExtraData(NiExtraData):
    buffer_type = PynBufferTypes.NiStringExtraDataBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)

    @classmethod 
    def getbuf(cls, values=None):
        return NiStringExtraDataBuf(values)

    @property 
    def string_data(self):
        """
        String value stored in this extra data block.
        """
        if self.properties.stringDataID == NODEID_NONE:
            return ""
        namebuf = (c_char * self.file.max_string_len)()
        nifly.getString(
            self.file._handle, self.properties.stringDataID, self.file.max_string_len, namebuf)
        return namebuf.value.decode('utf-8')
    
    @string_data.setter
    def string_data(self, value):
        """
        Set the string value for this extra data block.
        """
        self.properties.stringDataID = nifly.addString(
            self.file._handle, value.encode('utf-8'))
        if self.file and self.id != NODEID_NONE:
            check_return(nifly.setBlock, self.file._handle, self.id, byref(self.properties))

    @classmethod
    def New(cls, file, name='', string_value='', parent=None):
        p = NiStringExtraDataBuf()
        p.stringDataID = nifly.addString(file._handle, string_value.encode('utf-8'))
        return file.add_block(name, p, parent)


class BSBoneLODExtraData(NiExtraData):
    buffer_type = PynBufferTypes.BSBoneLODBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._lod_data = None

    @classmethod 
    def getbuf(cls, values=None):
        return BSBoneLODBuf(values)

    @property 
    def lod_data(self):
        """
        LOD data returned as [(bone_name, distance), ...]
        """
        if self._lod_data is None:
            self._lod_data = []
            if self.properties.lodCount > 0:
                lodbuf = (BoneLODInfoBuf * self.properties.lodCount)()
                check_msg(nifly.getBoneLODInfo, self.file._handle, self.id, byref(lodbuf), self.properties.lodCount)
                for li in lodbuf:
                    tn = create_string_buffer(256)
                    check_msg(nifly.getString, self.file._handle, li.nameID, 256, tn)
                    self._lod_data.append((tn.value.decode('utf-8'), li.distance))
        return self._lod_data
    
    @lod_data.setter
    def lod_data(self, value):
        """
        Set the LOD data for this extra data block.
        value: [(bone_name, distance), ...]
        """
        self._lod_data = value
        self.properties.lodCount = len(value)
        if self.file and self.id != NODEID_NONE:
            check_return(nifly.setBlock, self.file._handle, self.id, byref(self.properties))
            
            # Set the LOD info array
            lodbuf = (BoneLODInfoBuf * len(value))()
            for i, (bone_name, distance) in enumerate(value):
                lodbuf[i].distance = distance
                lodbuf[i].nameID = check_msg(
                    nifly.addString, self.file._handle, bone_name.encode('utf-8'))
            check_return(nifly.setBoneLOD, self.file._handle, self.id, len(value), byref(lodbuf))

    @classmethod
    def New(cls, file, name='', lodlist=None, parent=None):
        if lodlist is None:
            lodlist = []
        p = BSBoneLODBuf()
        p.lodCount = len(lodlist)
        bone_lod = file.add_block(name, p, parent)
        lodbuf = (BoneLODInfoBuf * len(lodlist))()
        for i, lod in enumerate(lodlist):
            lodbuf[i].distance = lod[1]
            lodbuf[i].nameID = check_msg(
                nifly.addString, file._handle, lod[0].encode('utf-8'))
        check_return(nifly.setBoneLOD, 
                     file._handle, bone_lod.id, len(lodlist), byref(lodbuf))
        return bone_lod


class BSInvMarker(NiExtraData):
    buffer_type = PynBufferTypes.BSInvMarkerBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)

    @classmethod 
    def getbuf(cls, values=None):
        return BSInvMarkerBuf(values)

    @property 
    def rotation(self):
        """
        Rotation values for inventory marker as (x, y, z) tuple.
        """
        return (self.properties.rot0, self.properties.rot1, self.properties.rot2)
    
    @rotation.setter
    def rotation(self, value):
        """
        Set the rotation values for inventory marker.
        value: (x, y, z) tuple
        """
        if len(value) != 3:
            raise ValueError("Rotation tuple must have exactly 3 values (x, y, z)")
        self.properties.rot0 = int(value[0])
        self.properties.rot1 = int(value[1])
        self.properties.rot2 = int(value[2])
        if self.file and self.id != NODEID_NONE:
            nifly.setBlock(self.file._handle, self.id, byref(self.properties))

    @property 
    def zoom(self):
        """
        Zoom value for inventory marker.
        """
        return self.properties.zoom
    
    @zoom.setter
    def zoom(self, value):
        """
        Set the zoom value for inventory marker.
        """
        self.properties.zoom = float(value)
        if self.file and self.id != NODEID_NONE:
            nifly.setBlock(self.file._handle, self.id, byref(self.properties))

    @classmethod
    def New(cls, file, name='INV', rotation=(0, 0, 0), zoom=1.0, parent=None):
        p = BSInvMarkerBuf()
        p.rot0 = int(rotation[0])
        p.rot1 = int(rotation[1])
        p.rot2 = int(rotation[2])
        p.zoom = float(zoom)
        return file.add_block(name, p, parent)


class BSXFlags(NiExtraData):
    buffer_type = PynBufferTypes.BSXFlagsBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)

    @classmethod 
    def getbuf(cls, values=None):
        return BSXFlagsBuf(values)

    @property 
    def flags(self) -> BSXFlagsValues:
        """
        BSX flags integer value.
        """
        return BSXFlagsValues(self.properties.integerData)
    
    @flags.setter
    def flags(self, value):
        """
        Set the BSX flags integer value.
        """
        self.properties.integerData = int(value)
        if self.file and self.id != NODEID_NONE:
            nifly.setBlock(self.file._handle, self.id, byref(self.properties))

    @classmethod
    def New(cls, file, name='BSX', flags=0, parent=None):
        p = BSXFlagsBuf()
        p.integerData = int(flags)
        return file.add_block(name, p, parent)
    

class BSConnectPointParents(NiExtraData):
    """
    These are a type of extra data but they get special handling. So this definition
    is a dummy so that reading extra data doesn't trip over them.
    TODO: Handle them like furniture markers.
    """
    buffer_type = PynBufferTypes.NiNodeBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._parents = None


class BSConnectPointChildren(NiExtraData):
    """Dummy class so BSConnectPoint::Children blocks are recognised and silently skipped."""
    buffer_type = PynBufferTypes.NiNodeBufType

    @classmethod 
    def getbuf(cls, values=None):
        return NiNodeBuf(values)


class NiControllerSequence(NiSequence):
    buffer_type = PynBufferTypes.NiControllerSequenceBufType
    
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._text_key_data = None

    @property
    def accumRootName(self):
        namebuf = (c_char * self.file.max_string_len)()
        nifly.getString(
            self.file._handle, 
            self.properties.accumRootNameID, 
            self.file.max_string_len, 
            namebuf)
        return namebuf.value.decode('utf-8')

    @property
    def is_cyclic(self):
        return self.properties.cycleType == 0
    
    @property
    def text_key_data(self) -> NiTextKeyExtraData:
        if self._text_key_data is None:
            self._text_key_data = self.file.read_node(
                id=self.properties.textKeyID)
        return self._text_key_data

    @classmethod
    def getbuf(cls, values=None):
        return NiControllerSequenceBuf(values)
    
    @classmethod
    def New(cls, file, name, accum_root_name=None, frequency=1, phase=0,
            start_time=0, stop_time=0, cycle_type=CycleType.CLAMP, weight=1.0,
            text_key_data=None, parent=None, 
            ):
        """
        Create a new controller sequence block.
        """
        p = NiControllerSequenceBuf()
        p.frequency = frequency
        p.phase = phase
        p.startTime = start_time
        p.stopTime = stop_time
        p.cycleType = cycle_type
        p.textKeyID = text_key_data.id if text_key_data else NODEID_NONE
        p.weight = weight

        if parent: p.managerID = parent.id
        if accum_root_name is not None:
            p.accumRootNameID = nifly.addString(
                file._handle, 
                accum_root_name.encode('utf-8'))

        cs = file.add_block(name, p, parent)
        cs._name = name
        if parent: parent.add_sequence(cs)
        return cs


class NiControllerManager(NiTimeController):
    buffer_type = PynBufferTypes.NiControllerManagerBufType

    def __init__(self, handle=None, file=None, id=NODEID_NONE, 
                 properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._properties = NiControllerManagerBuf()
        self._controller_manager_sequences = None
        self._object_palette = None
        check_return(nifly.getBlock,
                     self.file._handle, 
                     self.id, 
                     byref(self._properties))

    @property
    def sequences(self):
        if self._controller_manager_sequences != None:
            return self._controller_manager_sequences
        
        cms_count = nifly.getControllerManagerSequences(
            self.file._handle, self._handle, 0, None)
        cmsids = (c_uint32 * cms_count)()
        check_msg(
            nifly.getControllerManagerSequences,
            self.file._handle, self._handle, cms_count, cmsids)
        
        self._controller_manager_sequences = {}
        for id in cmsids:
            cs = NiControllerSequence(id=id, file=self.file)
            self._controller_manager_sequences[cs.name] = cs

        return self._controller_manager_sequences
    
    def add_sequence(self, seq):
        """
        Add the given controller sequence to the mananger.

        The nif file is not changed. 
        """
        self._controller_manager_sequences[seq.name] = seq

    @property
    def object_palette(self):
        if self._object_palette != None:
            return self._object_palette
        elif self.properties.objectPaletteID == NODEID_NONE:
            return None
        else:
            self._object_palette = self.file.read_node(
                self.properties.objectPaletteID)
            return self._object_palette

    @classmethod
    def getbuf(cls, values=None):
        return NiControllerManagerBuf(values)
    
    @classmethod
    def New(cls, file, flags:TimeControllerFlags, next_controller=None, 
            object_palette=None, parent=None):
        """
        Create a new controller manager block within the target file.
        """
        p = NiControllerManagerBuf()
        p.targetID = parent.id if parent else NODEID_NONE
        p.nextControllerID = next_controller.id if next_controller else NODEID_NONE
        p.flags = flags.flags
        p.objectPaletteID = object_palette.id if object_palette else NODEID_NONE
        cm = file.add_block(None, p, parent)
        cm._controller_manager_sequences = {}
        return cm


class NiDefaultAVObjectPalette(NiObject):
    buffer_type = PynBufferTypes.NiDefaultAVObjectPaletteBufType
    
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._objects = None

    @classmethod 
    def getbuf(cls, values=None):
        return NiDefaultAVObjectPaletteBuf(values)
    
    @property
    def objects(self):
        """
        Objects returned as dict {}"object name": object, ...}
        """
        if self._objects is None:
            self._objects = {}
            for i in range(0, self.properties.objCount):
                name = create_string_buffer(256)
                refid = (c_uint32)()
                nifly.getAVObjectPaletteObject(
                    self.file._handle,
                    self.id,
                    i, 
                    256, name,
                    refid
                )
                refnode = self.file.read_node(refid.value)
                self._objects[name.value.decode('utf-8')] = refnode
        return self._objects
    
    def add_object(self, objname, obj):
        if self._objects is None: 
            self._objects = {}
        if objname not in self._objects:
            nifly.addAVObjectPaletteObject(
                self.file._handle,
                self.id,
                objname.encode('utf8'),
                obj.id
            )
            self._objects[objname] = obj
    
    @classmethod
    def New(cls, file, scene=None, objects=None, parent=None):
        p = NiDefaultAVObjectPaletteBuf()
        p.sceneID = scene.id if scene else NODEID_NONE
        objp = file.add_block(None, p, parent)
        for name, obj in (objects or {}).items():
            objp.add_object(name, obj)
        return objp


# --- Shaders -- #

class NiAlphaProperty(NiProperty):
    @classmethod
    def getbuf(cls, values=None):
        return AlphaPropertyBuf(values)

    @property
    def parent(self):
        if not self._parent:
            for sh in self.file.shapes:
                if sh.properties.alphaPropertyID == self.id:
                    self._parent = sh
                    break 
        return self._parent


class NiShader(NiProperty):
    """
    Handles shader attributes for a Nif. In Skyrim, returns values from the underlying
    shader block. In FO4, most attributes come from the associated materials file.
    """
    buffer_type = PynBufferTypes.NiShaderBufType

    @classmethod
    def getbuf(cls, values=None):
        return NiShaderBuf(values)

    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        
        self._textures = None

    @property
    def parent(self):
        if not self._parent:
            for sh in self.file.shapes:
                if sh.properties.shaderPropertyID == self.id:
                    self._parent = sh
                    break 
        return self._parent
    
    # Names are handled simply, because they get written when the shader gets written.
    @property
    def name(self):
        return super().name
    
    @name.setter
    def name(self, val):
        if val:
            self._name = val

    def _readtexture(self, niffile, shape, layer):
        bufsize = 500
        buf = create_string_buffer(bufsize)
        check_msg(nifly.getShaderTextureSlot, niffile, shape, layer-1, buf, bufsize)
        return buf.value.decode('utf-8')

    @property
    def textures(self):
        if self._textures is None:
            self._textures = {}
            if self.properties.bufType == PynBufferTypes.BSLightingShaderPropertyBufType:
                f = self.file._handle
                s = self._parent._handle
                self._textures["Diffuse"] = self._readtexture(f, s, 1)
                self._textures["Normal"] = self._readtexture(f, s, 2)

                if self.properties.shaderflags2_test(ShaderFlags2.GLOW_MAP):
                    self._textures["Glow"] = self._readtexture(f, s, 3)

                try:
                    # Skyrim only
                    if self.properties.shaderflags2_test(ShaderFlags2.RIM_LIGHTING):
                        self._textures["RimLighting"] = self._readtexture(f, s, 3)
                    if self.properties.shaderflags2_test(ShaderFlags2.SOFT_LIGHTING):
                        self._textures["SoftLighting"] = self._readtexture(f, s, 3)
                    if self.properties.shaderflags1_test(ShaderFlags1.PARALLAX):
                        self._textures["HeightMap"] = self._readtexture(f, s, 4)
                    if self.properties.shaderflags1_test(ShaderFlags1.GREYSCALE_COLOR):
                        self._textures["Greyscale"] = self._readtexture(f, s, 4)
                    if self.properties.shaderflags2_test(ShaderFlags2.ENVMAP_LIGHT_FADE):
                        self._textures["EnvMap"] = self._readtexture(f, s, 5)
                    if self.properties.shaderflags1_test(ShaderFlags1.FACEGEN_DETAIL_MAP):
                        self._textures["FacegenDetail"] = self._readtexture(f, s, 7)
                except:
                    pass

                if (self.properties.shaderflags1_test(ShaderFlags1.ENVIRONMENT_MAPPING) 
                        or self.properties.shaderflags1_test(ShaderFlags1.EYE_ENVIRONMENT_MAPPING)):
                    self._textures["EnvMap"] = self._readtexture(f, s, 5)
                    self._textures["EnvMask"] = self._readtexture(f, s, 6)

                if self.properties.shaderflags2_test(ShaderFlags2.MULTI_LAYER_PARALLAX):
                    self._textures["InnerLayer"] = self._readtexture(f, s, 7)

                if (self.properties.shaderflags1_test(ShaderFlags1.MODEL_SPACE_NORMALS)
                    or self.properties.shaderflags1_test(ShaderFlags1.SPECULAR)):
                    self._textures["Specular"] = self._readtexture(f, s, 8)

                # The root material path lives in the shader block (rootMaterialNameID),
                # not the texture set. Expose it here so the block-read path matches
                # the material-read path, which also returns RootMaterialPath.
                if self.properties.rootMaterialNameID != NODEID_NONE:
                    self._textures["RootMaterialPath"] = self.file.get_string(
                        self.properties.rootMaterialNameID)

            if self.properties.bufType == PynBufferTypes.BSEffectShaderPropertyBufType:
                self._textures['Diffuse'] = self.properties.sourceTexture.decode()
                self._textures['Greyscale'] = self.properties.greyscaleTexture.decode()
                self._textures['EnvMap'] = self.properties.envMapTexture.decode()
                self._textures['Normal'] = self.properties.normalTexture.decode()
                self._textures['EnvMapMask'] = self.properties.envMaskTexture.decode()
                self._textures['EmitGradient'] = self.properties.emitGradientTexture.decode()

        return self._textures

    def set_texture(self, slot:str, texturepath):
        """Set texture in the named slot to the given string."""
        if self.properties.bufType == PynBufferTypes.BSLightingShaderPropertyBufType:
            if slot == 'Diffuse':
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 0, texturepath.encode('utf-8'))
            if slot == 'Normal':
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 1, texturepath.encode('utf-8'))
            if slot in ['Glow', 'RimLighting', 'SoftLighting']:
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 2, texturepath.encode('utf-8'))
            if slot == 'HeightMap':
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 3, texturepath.encode('utf-8'))
            if slot == 'EnvMap':
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 4, texturepath.encode('utf-8'))
            if slot == 'EnvMask':
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 5, texturepath.encode('utf-8'))
            if slot in ['FacegenDetail', 'InnerLayer']:
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 6, texturepath.encode('utf-8'))
            if slot == 'Specular':
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 7, texturepath.encode('utf-8'))
                
            if slot == 'Wrinkles':
                nifly.setShaderTextureSlot(
                    self.file._handle, self._parent._handle, 8, texturepath.encode('utf-8'))
        if self.properties.bufType == PynBufferTypes.BSEffectShaderPropertyBufType:
            if slot == 'Diffuse':
                self.properties.sourceTexture = texturepath.encode('utf-8')
            if slot == 'Greyscale':
                self.properties.greyscaleTexture = texturepath.encode('utf-8')
            if slot == 'EnvMap':
                self.properties.envMapTexture = texturepath.encode('utf-8')
            if slot == 'Normal':
                self.properties.normalTexture = texturepath.encode('utf-8')
            if slot == 'EnvMapMask':
                self.properties.envMaskTexture = texturepath.encode('utf-8')
            if slot == 'EmitGradient':
                self.properties.emitGradientTexture = texturepath.encode('utf-8')

    # Individual getter routines for shader flags so the caller doesn't have to worry
    # about Skyrim vs FO4.

    @property
    def flag_vertex_alpha(self):
        return self.properties.shaderflags1_test(ShaderFlags1.VERTEX_ALPHA)

    @property
    def flag_facegen_RBG_tint(self):
        return self.properties.shaderflags1_test(ShaderFlags1.FACEGEN_RGB_TINT)

    @property
    def flag_greyscale_color(self):
        return self.properties.shaderflags1_test(ShaderFlags1.GREYSCALE_COLOR)

    @property
    def flag_greyscale_alpha(self):
        return self.properties.shaderflags1_test(ShaderFlags1.GREYSCALE_ALPHA)

    @property
    def flag_decal(self):
        return self.properties.shaderflags1_test(ShaderFlags1.DECAL)

    @property
    def flag_environment_mapping(self):
        return self.properties.shaderflags1_test(ShaderFlags1.ENVIRONMENT_MAPPING)

    @property
    def flag_zbuffer_test(self):
        return self.properties.shaderflags1_test(ShaderFlags1.ZBUFFER_TEST)

    @property
    def flag_cast_shadows(self):
        return self.properties.shaderflags1_test(ShaderFlags1.CAST_SHADOWS)
        
    @property
    def flag_external_emittance(self):
        return self.properties.shaderflags1_test(ShaderFlags1.EXTERNAL_EMITTANCE)
        
    @property
    def flag_eye_environment_mapping(self):
        return self.properties.shaderflags1_test(ShaderFlags1.EYE_ENVIRONMENT_MAPPING)

    @property
    def flag_hair(self):
        # FO4 SLSF1 bit 18 (Skyrim names this bit HAIR_SOFT_LIGHTING).
        return self.properties.shaderflags1_test(ShaderFlags1FO4.HAIR)

    @property
    def flag_own_emit(self):
        return self.properties.shaderflags1_test(ShaderFlags1.OWN_EMIT)

    @property
    def flag_model_space_normals(self):
        return self.properties.shaderflags1_test(ShaderFlags1.MODEL_SPACE_NORMALS)

    @property
    def flag_rgb_falloff(self):
        # FO4-only SLSF1 bit 8 (Skyrim names this bit RECEIVE_SHADOWS).
        return self.properties.shaderflags1_test(ShaderFlags1FO4.RGB_FALLOFF)

    @property
    def flag_specular(self):
        return self.properties.shaderflags1_test(ShaderFlags1.SPECULAR)
        
    @property
    def flag_use_falloff(self):
        return self.properties.shaderflags1_test(ShaderFlags1.USE_FALLOFF)

    @property
    def flag_double_sided(self):
        return self.properties.shaderflags2_test(ShaderFlags2.DOUBLE_SIDED)

    @property
    def flag_vertex_colors(self):
        return self.properties.shaderflags2_test(ShaderFlags2.VERTEX_COLORS)

    @property
    def flag_no_fade(self):
        return self.properties.shaderflags2_test(ShaderFlags2.NO_FADE)

    @property
    def flag_glow_map(self):
        return self.properties.shaderflags2_test(ShaderFlags2.GLOW_MAP)

    @property
    def flag_zbuffer_write(self):
        return self.properties.shaderflags2_test(ShaderFlags2.ZBUFFER_WRITE)

    @property
    def flag_anisotropic_lighting(self):
        return self.properties.shaderflags2_test(ShaderFlags2.ANISOTROPIC_LIGHTING)

    @property
    def flag_transform_changed(self):
        # FO4 SLSF2 bit 7. The Skyrim ShaderFlags2 enum names this same bit
        # ASSUME_SHADOWMASK and has no TRANSFORM_CHANGED member, so referencing it
        # there raised AttributeError; use the FO4 enum for this FO4-only flag.
        return self.properties.shaderflags2_test(ShaderFlags2FO4.TRANSFORM_CHANGED)

    @property
    def flag_vats_target_draw_all(self):
        # FO4-only SLSF2 bit 27 (Skyrim names this bit BACK_LIGHTING).
        return self.properties.shaderflags2_test(ShaderFlags2FO4.VATS_TARGET_DRAW_ALL)

    @property
    def flag_gradient_remap(self):
        # FO4-only SLSF2 bit 26 (Skyrim names this bit RIM_LIGHTING).
        return self.properties.shaderflags2_test(ShaderFlags2FO4.GRADIENT_REMAP)

    @property
    def flag_alpha_test(self):
        # FO4-only SLSF2 bit 25 (Skyrim names this bit SOFT_LIGHTING).
        return self.properties.shaderflags2_test(ShaderFlags2FO4.ALPHA_TEST)

    @property
    def flag_tree_anim(self):
        return self.properties.shaderflags2_test(ShaderFlags2.TREE_ANIM)
        
    @property
    def flag_effect_lighting(self):
        return self.properties.shaderflags2_test(ShaderFlags2.EFFECT_LIGHTING)

    @property
    def flag_rim_lighting(self):
        return self.properties.shaderflags2_test(ShaderFlags2.RIM_LIGHTING)

    @property
    def flag_soft_lighting(self):
        return self.properties.shaderflags2_test(ShaderFlags2.SOFT_LIGHTING)

    @property
    def texture_clamp_mode(self):
        return self.properties.textureClampMode
    
    @texture_clamp_mode.setter
    def texture_clamp_mode(self, value):
        self.properties.textureClampMode = value

class BSDistantTreeShaderProperty(NiShader):
    pass


class BSLightingShaderProperty(NiShader):
    pass

class BSShaderLightingProperty(NiShader):
    pass

class BSShaderNoLightingProperty(NiShader):
    pass


class BSShaderProperty(NiShader):
    pass

class BSSkyShaderProperty(NiShader):
    pass

class BSWaterShaderProperty(NiShader):
    pass

class DistantLODShaderProperty(NiShader):
    pass

class HairShaderProperty(NiShader):
    pass

class Lighting30ShaderProperty(NiShader):
    pass

class NiMaterialProperty(NiShader):
    pass

class SkyShaderProperty(NiShader):
    pass

class TallGrassShaderProperty(NiShader):
    pass

class TileShaderProperty(NiShader):
    pass

class VolumetricFogShaderProperty(NiShader):
    pass

class WaterShaderProperty(NiShader):
    pass


class BSEffectShaderProperty(NiShader):
    buffer_type = PynBufferTypes.BSEffectShaderPropertyBufType

    @classmethod
    def getbuf(cls, values=None):
        b = NiShaderBuf(values)
        b.bufType = PynBufferTypes.BSEffectShaderPropertyBufType
        return b


class BSShaderPPLightingProperty(NiShader):
    buffer_type = PynBufferTypes.BSShaderPPLightingPropertyBufType

    @classmethod
    def getbuf(cls, values=None):
        b = NiShaderBuf(values)
        b.bufType = PynBufferTypes.BSShaderPPLightingPropertyBufType
        return b


class NiShaderFO4(NiShader):
    """
    Shader for FO4 nifs. Alters NiShader behavior to get values from the materials file
    when necessary.
    """
    def __init__(self, handle=None, file=None, id=NODEID_NONE, properties=None, parent=None):
        self._materials = None
        self._checked_for_materials = False
        super().__init__(handle=handle, file=file, id=id, properties=properties, parent=parent)
        self._checked_for_materials = False
        
    def _load_properties_from_materials(self):
        """Load materials properties into shader properties so the rest of the world doesn't have to care."""
        if not self._materials: return

        p = self._properties
        p.textureClampMode = self._materials.tileFlags
        p.UV_Offset_U = self._materials.UV_Offset_U
        p.UV_Offset_V = self._materials.UV_Offset_V
        p.UV_Scale_U = self._materials.UV_Scale_U
        p.UV_Scale_V = self._materials.UV_Scale_V
        p.Alpha = self._materials.Alpha
        p.Env_Map_Scale = self._materials.environmentMappingMaskScale
        # emittanceColor only exists in the BGSM when emitEnabled is set (the editor
        # hides it otherwise). When emit is off the material has no emissive colour,
        # so leave the shader block's value rather than clobbering it with black.
        # BGEM (effect) materials have no emitEnabled flag -- default True so they
        # keep copying as before.
        if getattr(self._materials, 'emitEnabled', True):
            # emittanceColor is RGB only; the material doesn't carry an emissive
            # alpha, so leave the block's alpha rather than forcing it.
            p.Emissive_Color[0] = self._materials.emittanceColor[0]
            p.Emissive_Color[1] = self._materials.emittanceColor[1]
            p.Emissive_Color[2] = self._materials.emittanceColor[2]
        p.Emissive_Mult = self._materials.emittanceMult
        p.Refraction_Str = self._materials.refractionPower
        p.Glossiness = self._materials.smoothness
        p.Rim_Light_Power = self._materials.rimPower
        p.subsurfaceRolloff = self._materials.subsurfaceRolloff
        p.fresnelPower = self._materials.fresnelPower

        # grayscaleToPaletteScale and wetnessControl_* are BGSM (lighting-shader)
        # properties; BGEM effect shaders don't carry them.
        if self._materials.signature == b'BGSM':
            p.grayscaleToPaletteScale = self._materials.grayscaleToPaletteScale

            # wetnessControl_* use -1.0 in the BGSM as an "unspecified" sentinel,
            # while the NIF block holds the real effective values. Copy a material
            # value only when it actually specifies one (>= 0); otherwise keep the
            # block value rather than clobbering it with the sentinel.
            for fld in ('wetnessSpecScale', 'wetnessSpecPower', 'wetnessMinVar',
                        'wetnessEnvmapScale', 'wetnessFresnelPower', 'wetnessMetalness'):
                matval = getattr(self._materials, fld, -1.0)
                if matval >= 0.0:
                    setattr(p, fld, matval)

        # Shader flags 1/2. The material is authoritative only for the bits it
        # actually represents (set/cleared individually below). Don't zero the
        # whole field first: NIF-level flags that no material property maps to --
        # notably SLSF1_Skinned -- live in the shader block and must survive the
        # material load. Starting from the block value preserves them.
        if self._materials.decal:
            p.shaderflags1_set(ShaderFlags1.DECAL)
        else:
            p.shaderflags1_clear(ShaderFlags1.DECAL)

        if self._materials.environmentMapping:
            p.shaderflags1_set(ShaderFlags1.ENVIRONMENT_MAPPING)
        else:
            p.shaderflags1_clear(ShaderFlags1.ENVIRONMENT_MAPPING)

        if self._materials.zbuffertest:
            p.shaderflags1_set(ShaderFlags1.ZBUFFER_TEST)
        else:
            p.shaderflags1_clear(ShaderFlags1.ZBUFFER_TEST)

        if self._materials.twoSided:
            p.shaderflags2_set(ShaderFlags2.DOUBLE_SIDED)
        else:
            p.shaderflags2_clear(ShaderFlags2.DOUBLE_SIDED)

        if self._materials.glowmap:
            p.shaderflags2_set(ShaderFlags2.GLOW_MAP)
        else:
            p.shaderflags2_clear(ShaderFlags2.GLOW_MAP)

        if self._materials.zbufferwrite:
            p.shaderflags2_set(ShaderFlags2.ZBUFFER_WRITE)
        else:
            p.shaderflags2_clear(ShaderFlags2.ZBUFFER_WRITE)

        if self._materials.grayscaleToPaletteColor:
            p.shaderflags1_set(ShaderFlags1.GREYSCALE_COLOR)
        else:
            p.shaderflags1_clear(ShaderFlags1.GREYSCALE_COLOR)

        if self._materials.signature == b'BGSM':
            if self._materials.skinTint:
                p.shaderflags1_set(ShaderFlags1.FACEGEN_RGB_TINT)
            else:
                p.shaderflags1_clear(ShaderFlags1.FACEGEN_RGB_TINT)

            if self._materials.castShadows:
                p.shaderflags1_set(ShaderFlags1.CAST_SHADOWS)
            else:
                p.shaderflags1_clear(ShaderFlags1.CAST_SHADOWS)

            if self._materials.anisoLighting:
                p.shaderflags2_set(ShaderFlags2.ANISOTROPIC_LIGHTING)
            else:
                p.shaderflags2_clear(ShaderFlags2.ANISOTROPIC_LIGHTING)

            if self._materials.tree:
                p.shaderflags2_set(ShaderFlags2.TREE_ANIM)
            else:
                p.shaderflags2_clear(ShaderFlags2.TREE_ANIM)

            if self._materials.externalEmittance:
                p.shaderflags1_set(ShaderFlags1.EXTERNAL_EMITTANCE)
            else:
                p.shaderflags1_clear(ShaderFlags1.EXTERNAL_EMITTANCE)

            if self._materials.environmentMappingEye:
                p.shaderflags1_set(ShaderFlags1.EYE_ENVIRONMENT_MAPPING)
            else:
                p.shaderflags1_clear(ShaderFlags1.EYE_ENVIRONMENT_MAPPING)

            if self._materials.hair:
                p.shaderflags1_set(ShaderFlags1.HAIR_SOFT_LIGHTING)
            else:
                p.shaderflags1_clear(ShaderFlags1.HAIR_SOFT_LIGHTING)

            # OWN_EMIT (SLSF1, bit 22) is NOT material-owned: vanilla FO4 blocks
            # carry it independently of the BGSM's emitEnabled (which controls the
            # material's own emittance colour, a different concept). Driving it off
            # emitEnabled dropped the block flag on nearly every FO4 shape. Leave
            # it to survive from the shader block, like SLSF1_Skinned.

            if self._materials.modelSpaceNormals:
                p.shaderflags1_set(ShaderFlags1.MODEL_SPACE_NORMALS)
            else:
                p.shaderflags1_clear(ShaderFlags1.MODEL_SPACE_NORMALS)

            if self._materials.specularEnabled:
                p.shaderflags1_set(ShaderFlags1.SPECULAR)
            else:
                p.shaderflags1_clear(ShaderFlags1.SPECULAR)

        if self._materials.signature == b'BGEM':
            if self._materials.falloffEnabled:
                p.shaderflags1_set(ShaderFlags1.USE_FALLOFF)
            else:
                p.shaderflags1_clear(ShaderFlags1.USE_FALLOFF)

            if self._materials.effectLightingEnabled:
                p.shaderflags2_set(ShaderFlags2.EFFECT_LIGHTING)
            else:
                p.shaderflags2_clear(ShaderFlags2.EFFECT_LIGHTING)

    @property
    def materials(self):
        """Return the materials file if any."""
        if not self._checked_for_materials:
            # Find and read the materials file if any. This is where the shader properties
            # will come from. Some FO4 nifs don't have materials files. Apparently (?)
            # they use the shader block attributes.
            if self.name:
                # Build search paths starting with the nif's own materials root
                altpaths = []
                
                # Add the nif's own materials root first
                if self.file.materialsRoot:
                    altpaths.append(self.file.materialsRoot)
                
                # Add any additional paths provided via alternate_paths attribute
                alternate_paths = getattr(self, 'alternate_paths', None)
                if alternate_paths:
                    if isinstance(alternate_paths, (list, tuple)):
                        altpaths.extend(alternate_paths)
                    else:
                        altpaths.append(alternate_paths)
                
                fullpath = find_referenced_file(self.name, self.file.filepath, root='materials',
                                                alt_pathlist=altpaths)
                if fullpath:
                    try:
                        self._materials = bgsmaterial.MaterialFile.Open(fullpath)
                    except Exception:
                        log.exception(
                            f"Could not read materials file '{fullpath}' "
                            f"referenced by shader '{self.name}'")
                        self._materials = None
                    if self._materials:
                        self._load_properties_from_materials()
                else:
                    log.warning(
                        f"Could not find materials file '{self.name}' "
                        f"(searched nif filetree and {len(altpaths)} alternate path(s))")
            self._checked_for_materials = True
        return self._materials
    
    @property
    def properties(self):
        """
        Return shader properties. Return the materials file properties if any; caller will
        have to deal with any properties that differ between FO4 and Skyrim. Return the
        properties buffer if no materials file.
        """
        if not self._properties:
            super().properties

        self.materials  # Force load of materials if any.

        return self._properties
        
    @property
    def textures(self):
        if self.materials:
            return self.materials.textures
        else:
            return super().textures
        

# Every FO4/Skyrim nif shape stores vertex indices (and numVertices) as 16-bit,
# so a single shape can address at most 65535 vertices. NiTriShapeData/NiTriStripsData
# also store their triangle count as 16-bit (another 65535 cap); the BS*TriShape
# family (FO4, and BSTriShape/BSSubIndexTriShape/BSDynamicTriShape on SSE) uses
# 32-bit triangle counts — and the FO4 segmentation (BSSITSSegment) uses 32-bit
# triangle indices — so those shapes are vertex-limited only.
NIF_MAX_U16 = 65535
_TRI_16BIT_BLOCKTYPES = frozenset({
    'NiTriShape', 'NiTriShapeData', 'NiTriStrips', 'NiTriStripsData'})

# A unit factor is only believed when it is the same ratio for this many bone axes, to
# this relative tolerance. Both are loose enough for half-precision node transforms and
# far tighter than the spread a genuinely posed rig produces.
_UNIT_SCALE_MIN_SAMPLES = 30
_UNIT_SCALE_TOLERANCE = 0.002


def node_unit_scale(nif, reference):
    """How many of `reference`'s units one of `nif`'s node-transform units is.

    Starfield is the one game that mixes unit systems: it ships skeleton.nif and
    skeleton_facebones.nif with their NiNode transforms in Havok metres, while the .mesh
    geometry those bones skin, the BSSkinBoneData binds, and our own reference skeletons
    are all in Bethesda game units. Importing such a file without converting puts its
    bones ~70x too close to the origin.

    The factor is measured, not assumed, because "Starfield nifs are in metres" is false --
    statics and weapons carry ordinary game-unit node transforms, and only the skeleton
    files are the odd ones out. So compare this nif's node positions against the reference
    skeleton's, bone by bone, and accept the ratio only when every shared bone agrees on
    it. A nif that is simply POSED differs from the reference per bone rather than by one
    scale, so its ratios scatter and we decline -- which is what keeps FO4 posed rigs
    (power armor) out of this.

    Returns 1.0 whenever there is nothing to convert or nothing to measure against.
    """
    if reference is None or nif is None:
        return 1.0

    ratios = []
    for name, node in nif.nodes.items():
        ref = reference.nodes.get(name)
        if ref is None:
            continue
        a = node.global_transform.translation
        b = ref.global_transform.translation
        for i in range(3):
            # Skip axes sitting near zero: their ratio is dominated by rounding.
            if abs(b[i]) > 0.05 and abs(a[i]) > 1e-6:
                ratios.append(b[i] / a[i])

    if len(ratios) < _UNIT_SCALE_MIN_SAMPLES:
        return 1.0

    lo, hi = min(ratios), max(ratios)
    if lo <= 0 or (hi - lo) / hi > _UNIT_SCALE_TOLERANCE:
        # Not one uniform scale, so not a unit difference. Posed rig, different skeleton,
        # or a nif that only incidentally shares bone names.
        return 1.0

    scale = sum(ratios) / len(ratios)
    # Close enough to 1 to be measurement noise rather than a different unit system.
    return 1.0 if abs(scale - 1.0) < _UNIT_SCALE_TOLERANCE else scale


def shape_size_error(nverts, ntris, blocktype):
    """Return an error message if a shape of the given block type would exceed the
    nif format's hard 16-bit limits, else None. `blocktype` is the block name the
    shape will be written as (e.g. 'BSTriShape', 'NiTriShape')."""
    if nverts > NIF_MAX_U16:
        return (f"has {nverts} vertices, over the {NIF_MAX_U16}-vertex limit "
                "(nif vertex indices are 16-bit). Reduce the poly count or split "
                "the mesh into multiple shapes.")
    if blocktype in _TRI_16BIT_BLOCKTYPES and ntris > NIF_MAX_U16:
        return (f"has {ntris} triangles, over the {NIF_MAX_U16}-triangle limit for "
                f"{blocktype} (triangle count is 16-bit). Reduce the poly count or "
                "split the mesh into multiple shapes.")
    return None


# --- NifShape --- #
class NiShape(NiNode):
    buffer_type = PynBufferTypes.NiShapeBufType

    @classmethod
    def New(cls, handle=None, shapetype=None, id=NODEID_NONE, file=None, parent=None, 
            properties=None):
        # cls.load_subclasses()
        if properties:
            shapetype = cls._buftype_name(properties.bufType)
        if not shapetype:
            if id == NODEID_NONE:
                id = nifly.getBlockID(file._handle, handle)
            buf = create_string_buffer(128)
            check_msg(nifly.getBlockname, file._handle, id, buf, 128)
            shapetype = buf.value.decode('utf-8')
        try:
            new_shape = False
            if not handle and id == NODEID_NONE:
                new_shape = True
                id = check_msg(
                    nifly.addBlock,
                    file._handle, 
                    None, 
                    byref(properties), 
                    parent.id if parent else None)
            if not handle:
                handle = check_msg(nifly.getBlockByID, id)
            
            s = file.read_node(
                handle=handle, id=id, parent=parent, properties=properties)
            if new_shape:
                s._partitions = []
            return s
        except KeyError:
            NifFile.log.warning(f"Shape type is not implemented: {shapetype}")
            return None
        except Exception as e:
            NifFile.log.error(f"Error creating shape of type {shapetype}: {e}")
            return None

    @classmethod
    def getbuf(cls, values=None):
        return NiShapeBuf(values)
    
    def __init__(self, handle=None, file=None, id=NODEID_NONE, parent=None, 
                 properties=None, name=""):
        super().__init__(handle=handle, file=file, id=id, parent=parent, 
                         properties=properties, name=name)
        self._bone_ids = None
        self._bone_names = None
        self._unique_bone_names = None
        self._normals = None
        self._colors = None
        self._scale = 1.0
        self._tris = None
        self._uvs = None
        self._textures = None
        self._is_skinned = False
        self._verts = None
        self._weights = None
        self._partitions = None
        self._partition_tris = None
        self._segment_file = ''
        self.is_head_part = False
        self._shader = None
        self._alpha = None

    def _setShapeXform(self):
        nifly.setTransform(self._handle, self.transform)

    @property
    def verts(self):
        if not self._verts:
            verts = (c_float * 3 * self.properties.vertexCount)()
            nifly.getVertsForShape(
                self.file._handle, self._handle, verts, self.properties.vertexCount * 3, 0)
            self._verts = [(v[0], v[1], v[2]) for v in verts]
        return self._verts

    @property
    def colors(self):
        """Returns colors as a list of 4-tuples representing color values, 1:1 with vertices."""
        if self._colors is None:
            if self.properties.hasVertexColors:
                buflen = self.properties.vertexCount
                buf = (c_float * 4 * buflen)()
                nifly.getColorsForShape(self.file._handle, self._handle, buf, buflen*4)
                self._colors = [(c[0], c[1], c[2], c[3]) for c in buf]
            else:
                self._colors = []
        return self._colors
    
    @property
    def normals(self):
        if not self._normals:
            buflen = self.properties.vertexCount 
            if buflen > 0:
                norms = (c_float * 3 * buflen)()
                nifly.getNormalsForShape(
                        self.file._handle, self._handle, norms, buflen * 3, 0)
                self._normals = [(n[0], n[1], n[2]) for n in norms]
        return self._normals

    @property
    def tris(self):
        if self._tris is None:
            triCount = self.properties.triangleCount
            buf = (c_uint16 * 3 * triCount)()
            nifly.getTriangles(
                    self.file._handle, self._handle, buf, triCount * 3, 0)
            self._tris = [(t[0], t[1], t[2]) for t in buf]
        return self._tris

    def _read_partitions(self):
        self._partitions = []
        buf = (c_uint16 * 2)()
        pc = nifly.getPartitions(self.file._handle, self._handle, None, 0)
        buf = (c_uint16 * 2 * pc)()
        pc = nifly.getPartitions(self.file._handle, self._handle, buf, pc)
        for i in range(pc):
            self._partitions.append(SkyPartition(buf[i][1], buf[i][0], namedict=self.file.dict))
    
    def _read_segments(self, num):
        self._partitions = []
        buf = (c_int * 2 * num)()
        pc = nifly.getSegments(self.file._handle, self._handle, buf, num)
        for i in range(num):
            p = FO4Segment(part_id=buf[i][0], index=i, subsegments=buf[i][1], namedict=self.file.dict)
            self._partitions.append(p)
            buf2 = (c_uint32 * 3 * p.subseg_count)()
            ssn = nifly.getSubsegments(self.file._handle, self._handle, p.id, buf2, p.subseg_count)
            for i in range(ssn):
                ss = FO4Subsegment(part_id=buf2[i][0],
                                   user_slot=buf2[i][1],
                                   material=buf2[i][2],
                                   parent=p,
                                   namedict=self.file.dict)
                # Pull cut offsets (slice-plane positions) for this subsegment.
                # Len+Data pattern: query count, then fill if any.
                cn = nifly.getSubsegmentCutOffsets(
                    self.file._handle, self._handle, ss.id, None, 0)
                if cn > 0:
                    cbuf = (c_float * cn)()
                    nifly.getSubsegmentCutOffsets(
                        self.file._handle, self._handle, ss.id, cbuf, cn)
                    ss.cut_offsets = [cbuf[k] for k in range(cn)]

    @property
    def partitions(self):
        if self._partitions is None:
            segc = nifly.segmentCount(self.file._handle, self._handle)
            if segc > 0:
                self._read_segments(segc)
            else:
                self._read_partitions()
        return self._partitions

    @property
    def partition_tris(self):
        """Returns a list of partition indices matching 1-1 with tris"""
        if self._partition_tris is None:
            buf = (c_uint16 * 1)()
            pc = nifly.getPartitionTris(self.file._handle, self._handle, None, 0)
            buf = (c_uint16 * pc)()
            pc = nifly.getPartitionTris(self.file._handle, self._handle, buf, pc)
            self._partition_tris = [0] * pc
            for i in range(pc):
                self._partition_tris[i] = buf[i]
        return self._partition_tris

    @property
    def segment_file(self):
        buflen = nifly.getSegmentFile(self.file._handle, self._handle, None, 0)+1
        buf = (c_char * buflen)()
        buflen = nifly.getSegmentFile(self.file._handle, self._handle, buf, buflen)
        self._segment_file = buf.value.decode('utf-8')
        return self._segment_file

    @segment_file.setter
    def segment_file(self, val):
        self._segment_file = val
    
    @property
    def uvs(self):
        if self._uvs is None:
            uvCount = self.properties.vertexCount
            buf = (c_float * 2 * uvCount)()
            check_msg(nifly.getUVs,
                    self.file._handle, self._handle, buf, uvCount * 2, 0)
            self._uvs = [(uv[0], uv[1]) for uv in buf]
        return self._uvs

    @property
    def skin_instance_name(self):
        """Return the block name of the skin instance, or '' if none."""
        sid = self.properties.skinInstanceID
        if sid == NODEID_NONE:
            return ''
        buf = create_string_buffer(128)
        nifly.getBlockname(self.file._handle, sid, buf, 128)
        return buf.value.decode('utf-8')

    @property
    def shader_block_name(self):
        buf = create_string_buffer(128)
        nifly.getBlockname(self.file._handle, self.properties.shaderPropertyID, buf, 128)
        return buf.value.decode('utf-8')

    @property
    def shaderflags1(self):
        return nifly.getShaderFlags1(self.file._handle, self._handle)

    @shaderflags1.setter
    def shaderflags1(self, val):
        nifly.setShaderFlags(self.file._handle, self._handle, val)

    @property
    def textures(self):
        return self.shader.textures

    def set_texture(self, slot:str, texturepath):
        """Set texture in the named slot to the given string."""
        self.shader.set_texture(slot, texturepath)
    
    @property
    def shader(self):
        """
        Returns a NiShaderBuf-like object associated with the shape. For Skyrim, this is
        the shader block; for FO4 it's the materials file associated with the shape's
        shader.
        """
        if self._shader is None:
            if self.file.game == 'FO4':
                self._shader = NiShaderFO4(
                    file=self.file, id=self.properties.shaderPropertyID, parent=self)
            else:
                self._shader = NiShader(
                    file=self.file, id=self.properties.shaderPropertyID, parent=self)

        return self._shader

    def save_shader_attributes(self):
        """
        Write out the shader attributes. FO4 files will have the shader properties written
        to the nif, not to a separate materials file.
        """
        if self._shader and self._shader._properties:
            name = self.shader.name
            if name is None: name = ''
            shader_id = nifly.addBlock(
                self.file._handle, 
                self._shader.name.encode('utf-8'), 
                byref(self._shader._properties), 
                self.id)
            self._shader.id = shader_id
            self.properties.shaderPropertyID = shader_id

    @property
    def has_alpha_property(self):
        return self.alpha_property != None
    
    @has_alpha_property.setter
    def has_alpha_property(self, val):
        if val and not self._alpha:
            self._alpha = NiAlphaProperty(file=self.file, parent=self)
    
    @property
    def alpha_property(self):
        if self._alpha is None and self.properties.alphaPropertyID != NODEID_NONE:
            self._alpha = NiAlphaProperty(
                file=self.file, id=self.properties.alphaPropertyID, parent=self)
        return self._alpha

    def save_alpha_property(self):
        if self._alpha:
            alpha_id = nifly.addBlock(
                self.file._handle, None, 
                byref(self._alpha.properties), self.id)
            self._alpha.id = alpha_id
            self.properties.alphaPropertyID = alpha_id

    @property
    def bone_names(self):
        """ List of bone names in the shape """
        if self._bone_names is None:
            bufsize = 300
            buf = create_string_buffer(bufsize+1)
            actualsize = nifly.getShapeBoneNames(self.file._handle, self._handle, buf, bufsize)
            if actualsize > bufsize:
                buf = create_string_buffer(actualsize+1)
                nifly.getShapeBoneNames(self.file._handle, self._handle, buf, actualsize+1)
            bn = buf.value.decode('utf-8').split('\n')
            self._bone_names = list(filter((lambda n: len(n) > 0), bn))
        return self._bone_names
        
    @property
    def bone_ids(self):
        if self._bone_ids is None:
            id_count = nifly.getShapeBoneCount(self.file._handle, self._handle)
            BUFDEF = c_int * id_count
            buf = BUFDEF()
            nifly.getShapeBoneIDs(self.file._handle, self._handle, buf, id_count)
            self._bone_ids = list(buf)
        return self._bone_ids

    @property
    def unique_bone_names(self):
        """Bone names deduplicated by node id, in first-occurrence order.

        The raw bone_names/bone_ids lists are partition-palette-aligned: a bone
        node repeats once per SkinPartition (skinned trees especially). This
        collapses those repeats to one name per distinct node.
        """
        if self._unique_bone_names is None:
            seen = set()
            result = []
            for nm, bid in zip(self.bone_names, self.bone_ids):
                if bid not in seen:
                    seen.add(bid)
                    result.append(nm)
            self._unique_bone_names = result
        return self._unique_bone_names

    def _bone_weights(self, bone_id):
        # Weights for all vertices (that are weighted to it)
        BUFSIZE = nifly.getShapeBoneWeightsCount(self.file._handle, self._handle, bone_id)
        BUFDEF = VERTEX_WEIGHT_PAIR * BUFSIZE
        buf = BUFDEF()
        nifly.getShapeBoneWeights(self.file._handle, self._handle,
                                          bone_id, buf, BUFSIZE)
        out = [(x.vertex, x.weight) for x in buf]
        return out

    @property
    def bone_weights(self):
        """ Dictionary of bone weights
            returns {bone-name: [(vertex-index, weight), ...], ...}

            Weights are aggregated by node id: the bone list is
            partition-palette-aligned, so a bone repeated across SkinPartitions
            carries a disjoint set of vertex weights at each palette position.
            Summing per vertex across those positions keeps every weight (a
            name-keyed overwrite would drop all but the last position).
            """
        if self._weights is None:
            by_id = {}     # node id -> {vertex: summed weight}
            id_name = {}   # node id -> name (first occurrence)
            for pos, (name, bid) in enumerate(zip(self.bone_names, self.bone_ids)):
                id_name.setdefault(bid, name)
                verts = by_id.setdefault(bid, {})
                for v, w in self._bone_weights(pos):
                    verts[v] = verts.get(v, 0.0) + w
            self._weights = {id_name[bid]: list(verts.items())
                             for bid, verts in by_id.items()}
        return self._weights

    def get_used_bones(self):
        """
        Return bones that have non-zero weights
        NOTE not really filtering out non-zero weights rn
        """
        return list(self.bone_weights.keys())

    @property
    def has_skin_instance(self):
        """ Determine whether this mash has a NiSkinData block.
            WARNING CURRENTLY BROKEN 
            """
        return nifly.hasSkinInstance(self._handle)

    @property
    def has_global_to_skin(self):
        """Determine whether the shape has the global-to-skin transform."""
        buf = TransformBuf()
        return nifly.getShapeGlobalToSkin(self.file._handle, self._handle, buf)
    
    def calc_global_to_skin(self):
        """Calculate the global-to-skin transform (whether or not it exists)."""
        buf = TransformBuf()
        nifly.calcShapeGlobalToSkin(self.file._handle, self._handle, buf)
        return buf
    
    @property
    def global_to_skin(self):
        """Return the global-to-skin transform on this shape; calculate it if not
        present. Calculated by averaging the skin-to-bone (pose) transforms on all the
        bones. 
        """
        buf = TransformBuf()
        has_xform = nifly.getShapeGlobalToSkin(self.file._handle, self._handle, buf)
        if not has_xform:
            nifly.calcShapeGlobalToSkin(self.file._handle, self._handle, buf)
        return buf

    def get_shape_skin_to_bone(self, bone_name):
        """ Return the skin-to-bone transform, getting it from the nif data """
        buf = TransformBuf()
        xform_found = nifly.getShapeSkinToBone(self.file._handle, 
                                                       self._handle, 
                                                       bone_name.encode('utf-8'),
                                                       buf)
        if xform_found:
            return buf
        else:
            return None

    def get_shape_skin_to_bone_by_index(self, bone_index):
        """Return the skin-to-bone transform for the bone at the given INDEX, or None.

        Starfield (BSGeometry/BSSkinBoneData) stores bind transforms indexed by position and
        carries no NiNode boneRefs, so the name-based lookup fails; this reads BSSkinBoneData
        directly by index. Bone index matches the order of unique_bone_names / SkinAttach.
        """
        buf = TransformBuf()
        xform_found = nifly.getShapeSkinToBoneByIndex(self.file._handle,
                                                      self._handle,
                                                      bone_index,
                                                      buf)
        return buf if xform_found else None

    def set_skin_to_bone_xform(self, bone_name, xform: TransformBuf):
        """Set the skin-to-bone transform on the shape's skin, using the skin."""
        nifly.setShapeSkinToBone(self.file._handle,
                                         self._handle,
                                         bone_name.encode('utf-8'),
                                         xform)


    # #############  Creating shapes #############

    def skin(self):
        nifly.skinShape(self.file._handle, self._handle)
        self._is_skinned = True

    def demote_skin_instance(self):
        """Replace BSDismemberSkinInstance with plain NiSkinInstance on this shape."""
        if nifly.demoteSkinInstance:
            nifly.demoteSkinInstance(self.file._handle, self._handle)

    def set_global_to_skin(self, transform):
        """ Sets the skin transform which offsets the vert locations. This allows a head
            to have verts around the origin but to be positioned properly when skinned.
            Works whether or not there is a SkinInstance block
            """
        if not self._is_skinned:
            self.skin()
        nifly.setShapeGlobalToSkin(self.file._handle, self._handle, transform)

    def add_bone(self, bone_name, xform=None, parent_name=None):
        """Add bone to shape. This resets all the shape's bone information, so 
        skin-to-bone transforms and bone weights will need to be reset.
        Add all bones first, then set transforms and weights.
        """
        if not self._is_skinned:
            self.skin()
        if xform:
            buf = xform
        else:
            buf = TransformBuf() 
            buf.set_identity()
        
        par = None
        if parent_name:
            par = parent_name.encode('utf-8')
        
        h = nifly.addBoneToNifShape(self.file._handle, self._handle, 
                                            bone_name.encode('utf-8'), buf,
                                            par)
        NiNode(handle=h, file=self.file, name=bone_name)

        
    def setShapeWeights(self, bone_name, vert_weights):
        """ Set the weights for a bone in a shape. 
        """
        VERT_BUF_DEF = VERTEX_WEIGHT_PAIR * len(vert_weights)
        vert_buf = VERT_BUF_DEF()
        for i, vw in enumerate(vert_weights):
            vert_buf[i].vertex = vw[0]
            vert_buf[i].weight = vw[1]
        xfbuf = TransformBuf()

        nifly.setShapeBoneWeights(self.file._handle, self._handle, 
                                      bone_name.encode('utf-8'),
                                      vert_buf, len(vert_weights))
       
    def set_partitions(self, partitionlist, trilist):
        """ Set the partitions for a shape
            partitionlist = list of Partition objects, either Skyrim or FO. Any Subsegments in the
                list are ignored. Subsegments are found separately under Partitions.
            trilist = 1:1 with shape tris. For Skyrim, each entry is either a partition ID
                (e.g. 130, 143) or an index into partitionlist (0, 1, ...) — the values from
                NiShape.partition_tris are accepted directly. For FO4, entries must be
                segment/subsegment IDs (the partition_tris values).
            """
        if len(partitionlist) == 0:
            return
        
        # In FO4, create a clean list of segments covering subsegments in partitionlist.
        # In Skyrim, just use the partitionlist as given.
        if self.file.game == 'FO4':
            pdict = {}
            maxid = max([p.id for p in partitionlist])
            for p in partitionlist:
                if type(p).__name__ == "FO4Subsegment":
                    seg_new = p.parent
                elif type(p).__name__ == "FO4Segment":
                    seg_new = p
                if seg_new.name not in pdict:
                    pdict[seg_new.name] = seg_new
                # All prior segments must also be included
                for i in range(0, seg_new.index):
                    if f"FO4 Seg {i:03d}" not in pdict:
                        maxid += 1
                        pdict[f"FO4 Seg {i:03d}"] = FO4Segment(part_id=maxid, index=i)
            parts = list(pdict.values())
            parts.sort(key=lambda x: x.index)
        else:
            parts = list(filter(
                lambda x: type(x).__name__ == "SkyPartition", 
                partitionlist))

        if len(parts) == 0:
            return

        parts_lookup = {}
        
        tbuf = (c_uint16 * len(trilist))()

        if self.file.game in ['SKYRIM', 'SKYRIMSE']:
            # nifly wants indices into the partition list. The trilist may already be
            # indices (as returned by partition_tris) or partition IDs (the older idiom).
            pbuf = (c_uint16 * 2 * len(parts))()
            for i, p in enumerate(parts):
                pbuf[i][0] = 0
                pbuf[i][1] = p.id
                parts_lookup[p.id] = i

            # Auto-detect: if every value matches a partition ID, treat as IDs;
            # otherwise if every value is a valid index, treat as indices.
            n = len(parts)
            all_ids = all(t in parts_lookup for t in trilist)
            all_indices = all(0 <= t < n for t in trilist)
            as_indices = all_indices and not all_ids

            for i, t in enumerate(trilist):
                if as_indices:
                    tbuf[i] = t
                else:
                    try:
                        tbuf[i] = parts_lookup[t]
                    except KeyError:
                        # Report the error unless the id is 0--that means we couldn't assign the
                        # partition and that error has already been reported
                        if t != 0:
                            log.error(f"Tri at index {i} assigned partition id {t}, but no such partition defined")
                            log.error(f"Partitions are {parts_lookup.items()}")
                        tbuf[i] = pbuf[0][1] # Export with the first partition so we get something out

            nifly.setPartitions(self.file._handle, self._handle,
                                        pbuf, len(parts),
                                        tbuf, len(trilist))
        else:
            # For segments, the trilist has to refer to IDs becuase of referring to subsegments.
            pbuf = (c_uint16 * len(parts))()
            for i, p in enumerate(parts):
                pbuf[i] = p.id 
                parts_lookup[p.id] = i

            for i, t in enumerate(trilist): 
                tbuf[i] = trilist[i]

            sslist = []
            cutcounts = []   # one entry per subsegment, parallel to sslist quads
            cutdata = []     # concatenated cut-offset floats
            for seg in parts:
                for sseg in seg.subsegments:
                    sslist.extend([sseg.id, seg.id, sseg.user_slot, sseg.material])
                    co = getattr(sseg, "cut_offsets", None) or []
                    cutcounts.append(len(co))
                    cutdata.extend(co)
            sbuf = (c_uint32 * len(sslist))()
            for i, s in enumerate(sslist):
                sbuf[i] = s
            ccbuf = (c_uint32 * len(cutcounts))()
            for i, n in enumerate(cutcounts):
                ccbuf[i] = n
            cdbuf = (c_float * len(cutdata))()
            for i, v in enumerate(cutdata):
                cdbuf[i] = v

            nifly.setSegments(self.file._handle, self._handle,
                                      pbuf, len(parts),
                                      sbuf, int(len(sslist)/4),
                                      tbuf, len(trilist),
                                      self._segment_file.encode('utf-8'),
                                      ccbuf, len(cutcounts),
                                      cdbuf, len(cutdata))

    def set_colors(self, colors):
        buf = (c_float * 4 * len(colors))()
        for i, c in enumerate(colors):
            buf[i][0] = c[0]
            buf[i][1] = c[1]
            buf[i][2] = c[2]
            buf[i][3] = c[3]
        nifly.setColorsForShape(self.file._handle, self._handle, 
                                        buf, len(colors))


# --- NiTriShape --- #
class NiTriShape(NiShape):
    buffer_type = PynBufferTypes.NiTriShapeBufType

    @classmethod
    def getbuf(cls, values=None):
        return NiTriShapeBuf(values)
    
class BSSegmentedTriShape(NiTriShape):
    pass

class NiScreenElements(NiTriShape):
    pass
    

# --- BSTriShape --- #
class BSTriShape(NiShape):
    buffer_type = PynBufferTypes.BSTriShapeBufType

    @classmethod
    def getbuf(cls, values=None):
        b = BSTriShapeBuf(values)
        b.bufType = PynBufferTypes.BSTriShapeBufType
        return b


# --- BSDynamicTriShape --- #
class BSDynamicTriShape(NiShape):
    buffer_type = PynBufferTypes.BSDynamicTriShapeBufType

    @classmethod
    def getbuf(cls, values=None):
        b = BSDynamicTriShapeBuf(values)
        b.bufType = PynBufferTypes.BSDynamicTriShapeBufType
        return b


# --- BSSubIndexTriShape --- #
class BSSubIndexTriShape(NiShape):
    buffer_type = PynBufferTypes.BSSubIndexTriShapeBufType

    @classmethod
    def getbuf(cls, values=None):
        b = BSSubIndexTriShapeBuf(values)
        b.bufType = PynBufferTypes.BSSubIndexTriShapeBufType
        return b


# --- BSGeometry (Starfield) --- #
class BSGeometry(NiShape):
    """Starfield geometry shape. Holds one mesh slot per LOD; each slot's geometry lives in
    an external .mesh file (referenced by meshName) and isn't present until load_mesh() feeds
    the bytes. Once a slot is loaded+selected, the normal geometry/bone accessors work (nifly
    routes them through GetGeometryData and reads bones from SkinAttach)."""
    buffer_type = PynBufferTypes.BSGeometryBufType

    @classmethod
    def getbuf(cls, values=None):
        # C++ reads a BSGeometry block as a plain NiShapeBuf (no distinct C++ bufType).
        return NiShapeBuf(values)

    @property
    def colors(self):
        """Per-vertex colors of the loaded/selected .mesh. A BSGeometry keeps its colors in the
        external .mesh (BSGeometryMeshData.vColors), which the generic color accessor doesn't
        read -- so route through the dedicated reader (else every color is black)."""
        if self._colors is None:
            n = len(self.verts)
            if n:
                buf = (c_float * 4 * n)()
                got = nifly.getBSGeometryColors(self.file._handle, self._handle, buf, n)
                self._colors = [(c[0], c[1], c[2], c[3]) for c in buf[:got]]
            else:
                self._colors = []
        return self._colors

    @property
    def mesh_count(self):
        """Number of LOD mesh slots."""
        return nifly.getBSGeometryMeshCount(self.file._handle, self._handle)

    @property
    def is_internal_geom(self):
        """True if mesh data is embedded in the NIF (flag 0x200) vs an external .mesh."""
        return bool(nifly.getBSGeometryInternalFlag(self.file._handle, self._handle))

    def mesh_path(self, slot=0):
        """The external .mesh path (verbatim meshName) for LOD slot `slot`."""
        buf = create_string_buffer(256)
        n = nifly.getBSGeometryMeshPath(self.file._handle, self._handle, slot, buf, 256)
        if n >= 256:
            buf = create_string_buffer(n + 1)
            nifly.getBSGeometryMeshPath(self.file._handle, self._handle, slot, buf, n + 1)
        return buf.value.decode('utf-8')

    def mesh_paths(self):
        """All LOD mesh paths, one per slot."""
        return [self.mesh_path(i) for i in range(self.mesh_count)]

    def load_mesh(self, data, slot=0):
        """Load external .mesh bytes into LOD slot `slot` and select it. Refreshes the cached
        geometry so verts/tris/normals/uvs/weights read from the loaded mesh."""
        ok = nifly.loadBSGeometryMeshData(
            self.file._handle, self._handle, slot, data, len(data))
        self._invalidate_geometry()
        return bool(ok)

    def select_mesh(self, slot):
        """Select which LOD slot the geometry accessors read from."""
        nifly.selectBSGeometryMesh(self.file._handle, self._handle, slot)
        self._invalidate_geometry()

    def save_mesh(self, slot=0):
        """Serialize LOD slot `slot` to external-.mesh bytes (regenerating meshlets + cull
        data first) and return them, ready to write to the resolved .mesh path. Returns
        b"" if the slot has no data."""
        n = nifly.saveBSGeometryMeshData(self.file._handle, self._handle, slot, None, 0)
        if n <= 0:
            return b""
        buf = create_string_buffer(n)
        nifly.saveBSGeometryMeshData(self.file._handle, self._handle, slot, buf, n)
        return buf.raw[:n]

    def set_mesh_name(self, name, slot=0):
        """Set the external .mesh path (meshName) the NIF references for LOD slot `slot`.
        The .mesh bytes themselves are written separately via save_mesh()."""
        nifly.setBSGeometryMeshName(
            self.file._handle, self._handle, slot, name.encode('utf-8'))
        self._invalidate_geometry()

    def set_mesh_tangents(self, tangents, tangent_ws=None, slot=0):
        """Set per-vertex tangents for LOD slot `slot`. tangents = [(x,y,z)...]; tangent_ws =
        the 2-bit bitangent-sign W of each tangent (1 or 3), defaulting to 1 if omitted."""
        n = len(tangents)
        tbuf = (c_float * 3 * n)()
        for i, t in enumerate(tangents):
            tbuf[i] = (t[0], t[1], t[2])
        wbuf = (c_uint8 * n)()
        for i in range(n):
            wbuf[i] = (tangent_ws[i] if tangent_ws else 1)
        nifly.setBSGeometryTangents(
            self.file._handle, self._handle, slot, tbuf, wbuf, n)

    def set_mesh_colors(self, colors, slot=0):
        """Set per-vertex colors for LOD slot `slot`. colors = [(r,g,b,a)...] floats 0..1,
        stored as the .mesh's byte colors."""
        n = len(colors)
        cbuf = (c_float * 4 * n)()
        for i, c in enumerate(colors):
            cbuf[i] = (c[0], c[1], c[2], c[3] if len(c) > 3 else 1.0)
        nifly.setBSGeometryColors(self.file._handle, self._handle, slot, cbuf, n)

    def skin_bones(self, bone_names, weights_per_vertex=4):
        """Set up SF skinning: create the BSSkin::Instance + BSSkin::BoneData (identity binds)
        + SkinAttach carrying `bone_names` (in order), set the mesh's weightsPerVertex, and zero
        the per-vertex weight slots. `weights_per_vertex` sizes the .mesh's uniform weight slots
        (nifly caps set_vert_weights to it), so pass the max influence count the shape will use.
        Call set_bone_bind() + set_vert_weights() afterward. Geometry must already be set."""
        namesNL = "\n".join(bone_names).encode('utf-8')
        nifly.skinBSGeometry(self.file._handle, self._handle, namesNL, len(bone_names),
                             weights_per_vertex)
        self._invalidate_geometry()

    def set_bone_bind(self, bone_index, xform: TransformBuf):
        """Set the skin-to-bone (bind) transform for the bone at `bone_index` (SkinAttach
        order). Pass the bind in game units; the DLL divides translation by havokScale."""
        nifly.setBSGeometryBoneBind(self.file._handle, self._handle, bone_index, xform)

    def set_vert_weights(self, vert_index, bone_indices, weights):
        """Set the bone weights for one vertex. bone_indices index the shape's bone list
        (SkinAttach order); weights are floats (nifly normalizes + quantizes into the .mesh)."""
        n = len(bone_indices)
        bbuf = (c_uint8 * n)(*bone_indices)
        wbuf = (c_float * n)(*weights)
        nifly.setBSGeometryVertWeights(self.file._handle, self._handle, vert_index, bbuf, wbuf, n)

    def update_skin_bounds(self):
        """Recompute the per-bone bounding spheres in BSSkin::BoneData from the current binds +
        vertex weights. Call once after all set_bone_bind()/set_vert_weights() calls. Leaving the
        default zero-radius spheres crashes the Creation Kit when it opens an actor using the mesh."""
        nifly.updateBSGeometrySkinBounds(self.file._handle, self._handle)

    def _invalidate_geometry(self):
        # vertexCount/triangleCount live in the cached NiShapeBuf, which is stale once a
        # different .mesh slot is loaded/selected. Clear it and the geometry caches so they
        # re-read against the now-current mesh.
        self._properties = None
        self._verts = self._tris = self._uvs = self._normals = self._colors = None
        self._weights = self._bone_names = self._bone_ids = self._unique_bone_names = None

    @property
    def tris(self):
        """BSGeometry doesn't populate NiGeometryData's 16-bit triangleCount, so size the
        buffer from getTriangles' authoritative return value (a second pass if the first
        buffer was too small)."""
        if self._tris is None:
            cap = max(self.properties.vertexCount * 4, 64)
            buf = (c_uint16 * 3 * cap)()
            n = nifly.getTriangles(self.file._handle, self._handle, buf, cap * 3, 0)
            if n > cap:
                cap = n
                buf = (c_uint16 * 3 * cap)()
                nifly.getTriangles(self.file._handle, self._handle, buf, cap * 3, 0)
            self._tris = [(buf[i][0], buf[i][1], buf[i][2]) for i in range(n)]
        return self._tris

    @property
    def unique_bone_names(self):
        """SkinAttach bone names are already unique -- no partition-palette repetition."""
        return self.bone_names

    @property
    def bone_weights(self):
        """SF weights are keyed by bone INDEX (position in the SkinAttach bone list). There
        are no node-ref bone IDs, so the base class's id-based dedup doesn't apply."""
        if self._weights is None:
            self._weights = {name: self._bone_weights(i)
                             for i, name in enumerate(self.bone_names)}
        return self._weights


# --- NiTriStrips --- #
class NiTriStrips(NiShape):
    buffer_type = PynBufferTypes.NiTriStripsBufType

    @classmethod
    def getbuf(cls, values=None):
        return NiTriStripsBuf(values)


# --- BSMeshLODTriShape --- #
class BSMeshLODTriShape(NiShape):
    buffer_type = PynBufferTypes.BSMeshLODTriShapeBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSMeshLODTriShapeBuf(values)


# --- BSLODTriShape --- #
class BSLODTriShape(NiShape):
    buffer_type = PynBufferTypes.BSLODTriShapeBufType

    @classmethod
    def getbuf(cls, values=None):
        return BSLODTriShapeBuf(values)


# --- NifFile --- #
class NifFile:
    """ NifFile represents the file itself. Corresponds approximately to a NifFile in the 
        Nifly layer, but we've hidden the AnimInfo object in here too.
        """
    has_extra_data = True
    log = logging.getLogger("pynifly")

    def Load(path):
        # No longer needed since library loads automatically
        pass
    
    def __init__(self, filepath=None, materialsRoot=None):
        """
        Initialize the nif file object.
        For ease of testing, materialsRoot indicates where to find the materials files. If
        not provided, the nif's own path will be used.
        """
        self.filepath = filepath
        self._handle = None
        self._game = None
        self._root = None
        if filepath is not None:
            self._handle = nifly.load(str(filepath).encode('utf-8'))
            if not self._handle:
                raise Exception(f"Could not open '{filepath}' as nif")
        self._skin_handle = None
        if self.game is not None:
            self.dict = gameSkeletons[self.game]
        self._bgdata = None
        self._strdata = None
        self._clothdata = None
        self._furniture_markers = None
        self._connect_pt_par = None
        self._connect_pt_child = None
        self.connect_pt_child_skinned = False
        self._ref_skel = None
        self.materialsRoot = ''
        if materialsRoot:
            self.materialsRoot = materialsRoot  
        elif filepath: 
            self.materialsRoot = extend_filenames(filepath, 'meshes')
        self._shape_dict = {}
        self.node_ids = {}
        self._nodes = None
        self._shapes = None
        self._max_string_len = None
        self._load_shapes()

    def __del__(self):
        if self._handle:
            nifly.destroy(self._handle)

    @property
    def max_string_len(self):
        """Length of buffer required for the longest string stored in the nif + one for
        the trailing null byte. Return at least 128 because reasons.

        Cached after first call: the DLL scans every string to compute this, and it's
        called once per string read. Recomputing each time is O(strings²).
        """
        if self._max_string_len is not None:
            return self._max_string_len
        if self._handle:
            self._max_string_len = max(128, nifly.getMaxStringLen(self._handle)+1)
        else:
            self._max_string_len = 128
        return self._max_string_len
        
    @property
    def reference_skel(self):
        if self._ref_skel:
            return self._ref_skel

        # We don't actually know which skeleton to use. Assume the basic human skeleton.
        g = "SKYRIM" if self._game == "SKYRIMSE" else self._game
        if g:
            skel_path = os.path.join(os.path.dirname(nifly_path), "Skeletons", g, "skeleton.nif")
            if os.path.exists(skel_path):
                self._ref_skel = NifFile(skel_path)
                return self._ref_skel

        return None


    def initialize(self, target_game, filepath, root_type="NiNode", root_name='Scene Root'):
        self.filepath = filepath
        self._game = target_game
        rt = 0
        self._handle = nifly.createNif(target_game.encode('utf-8'),
                                               root_type.encode('utf-8'),
                                               root_name.encode('utf-8'))
        self.dict = gameSkeletons[target_game]
        # Get the root node into the nodes list so it can be found.
        self.read_node(0)


    def save(self):
        for sh in self.shapes:
            sh._setShapeXform()

        if self._skin_handle:
            nifly.saveSkinnedNif(self._skin_handle, self.filepath.encode('utf-8'))
        else:
            nifly.saveNif(self._handle, self.filepath.encode('utf-8'))


    def get_string(self, string_id):
        buflen = self.max_string_len
        buf = (c_char * buflen)()
        check_msg(nifly.getString, self._handle, string_id, buflen, buf)
        return buf.value.decode('utf-8')


    def add_block(self, name, buf, parent=None):
        """
        Add a block defined by the given buffer to the nif file, with error-checking.
        Returns the new object created.
        """
        id = check_msg(nifly.addBlock,
            self._handle, 
            (name.encode('utf-8') if name else None), 
            byref(buf), 
            parent.id if parent else NODEID_NONE)
        if id == NODEID_NONE or id == -1:
            raise Exception(f"Could not create node {buf.bufType}/{NiObject._buftype_name(buf.bufType)}, error: {NifFile.message_log()}")
        cls = NiObject.buffer_types[buf.bufType]
        blk = cls(file=self, id=id, properties=buf, parent=parent)
        return blk


    def add_node(self, name, xform, parent=None):
        """Add NiNode object to the file."""
        phandle = None
        if parent:
            if type(parent) == str:
                phandle = nifly.findNodeByName(self._handle, parent.encode('utf-8'))
            else:
                phandle = parent._handle
        nodeh = nifly.addNode(self._handle, name.encode('utf-8'), xform, phandle)
        return NiNode(handle=nodeh, file=self, parent=parent)


    def createShapeFromData(self, shape_name, verts, tris, uvs, normals, 
                            props:NiShapeBuf=None,
                            use_type=PynBufferTypes.NiShapeBufType, 
                            parent=None):
        """ Create the shape from the data provided
            shape_name = Name of shape
            verts = [(x, y, z)...] vertex location
            tris = [(v1, v2, v3)...] triangles
            uvs = [(u, v)...] uvs, as many as there are verts
            normals = [(x, y, z)...] UVs, as many as there are verts
            props = Properties for the new shape; use defaults if omitted
            use_tyep = Block type for the new shape; only used if props omitted
            parent = Parent object or root
            """
        if props:
            shapebuf = props
        else:
            shapebuf = NiShapeBuf()
            shapebuf.bufType = use_type
        shapebuf.vertexCount = len(verts)
        shapebuf.triangleCount = len(tris)

        parenthandle = None
        if parent:
            parenthandle = parent._handle

        VERTBUFDEF = c_float * 3 * len(verts)
        vertbuf = VERTBUFDEF()
        normbuf = None
        norm_len = 0
        for i in range(0, len(verts)):
            vertbuf[i] = verts[i]
        if normals:
            normbuf = VERTBUFDEF()
            norm_len = len(normals)
            for i in range(norm_len):
                normbuf[i] = normals[i]
        
        TRIBUFDEF = c_uint16 * 3 * len(tris)
        tribuf = TRIBUFDEF()
        for i, t in enumerate(tris): tribuf[i] = t

        UVBUFDEF = c_float * 2 * len(uvs)
        uvbuf = UVBUFDEF()
        for i, u in enumerate(uvs): uvbuf[i] = (u[0], u[1])

        shape_handle = nifly.createNifShapeFromData(
            self._handle, 
            shape_name.encode('utf-8'), 
            byref(shapebuf),
            vertbuf, uvbuf, normbuf, 
            tribuf, 
            parenthandle)
        
        if self._shapes is None:
            self._shapes = []
        # Starfield renderables are BSGeometry blocks (the DLL creates one for any SF nif);
        # wrap the handle in the matching class so the caller gets the .mesh setters/save_mesh.
        shape_class = BSGeometry if self.game == 'SF' else NiShape
        sh = shape_class(handle=shape_handle, file=self, parent=parent)
        sh._name = shape_name
        sh._partitions = []
        self._shapes.append(sh)
        sh._handle = shape_handle
        self.shape_dict[sh.name] = sh

        return sh

    @property
    def rootName(self):
        """Return name of root node"""
        return self.root.name
    
    @property
    def root(self):
        """Return handle of root node."""
        if self._root is None:
            self._root = self.read_node(0)
        return self._root

    @property 
    def rootNode(self) -> NiNode:
        """Return the root node of the nif. 
        NOT TRUE: Note this causes all nodes to be loaded and nif.nodes to be filled.
        """
        return self.root
    
    @property
    def game(self):
        """Return name of the game the Nif file is for"""
        if self._game is None and self._handle is not None:
            buf = create_string_buffer(50)
            nifly.getGameName(self._handle, buf, 50)
            self._game = buf.value.decode('utf-8')
            self.dict = gameSkeletons[self._game]
        return self._game

    def blender_name(self, nif_name):
        """Convert name in nif to name for blender"""
        return self.dict.blender_name(nif_name)

    def nif_name(self, blender_name):
        """Convert name in blender to name for nif"""
        return self.dict.nif_name(blender_name)
    
    def getAllShapeNames(self):
        buf = create_string_buffer(300)
        nifly.getAllShapeNames(self._handle, buf, 300)
        return buf.value.decode('utf-8').split('\n')

    @property
    def shape_dict(self):
        self.shapes
        return self._shape_dict

    def _load_shapes(self):
        self._shapes = []
        self._shape_dict = {}
        if self._handle:
            nfound = nifly.getShapes(self._handle, None, 0, 0)
            PTRBUF = c_void_p * nfound
            buf = PTRBUF()
            nfound = nifly.getShapes(self._handle, buf, nfound, 0)
            for i in range(nfound):
                new_shape = NiShape.New(file=self, handle=buf[i])
                if new_shape:
                    self._shapes.append(new_shape) # not handling too many shapes yet
                    self._shape_dict[new_shape.name] = new_shape
        self._shapes_loaded = True

    @property
    def shapes(self):
        return self._shapes
    
    def shape_by_root(self, rootname):
        """ Convenience routine to find a shape by the beginning part of its name """
        for s in self.shapes:
            if s.name.startswith(rootname):
                return s
        return None


    def register_node(self, n):
        if n.name: self.nodes[n.name] = n
        if n.id != NODEID_NONE: self.node_ids[n.id] = n
        if n.id == 0: self._root = n
        if isinstance(n, NiShape) and n.name:
            self._shape_dict[n.name] = n


    def unregister_name(self, n):
        if n.name: del self.nodes[n.name]
        if isinstance(n, NiShape) and n.name in self._shape_dict:
            del self._shape_dict[n.name]


    @property
    def nodes(self):
        """Dictionary of nodes in the nif, indexed by node name."""
        # Node names do not have to be unique, except in the case of skeleton bones. 
        # nodes should not be used to find all nodes; use node_ids for that.
        if self._nodes is None:
            self._nodes = {}
            nodeCount = nifly.getNodeCount(self._handle)
            PTRBUF = c_void_p * nodeCount
            buf = PTRBUF()
            nifly.getNodes(self._handle, buf)
            for h in buf:
                this_node = self.read_node(handle=h)
        return self._nodes


    def nodeByHandle(self, desired_handle):
        """ 
        Returns the node with the given handle. If not found assumes it's a node that
        doesn't appear in the nodes list and makes a NiNode for it. 
        """
        for n in self.node_ids.values():
            if n._handle == desired_handle:
                return n
        return self.read_node(handle=desired_handle)


    def get_node_xform_to_global(self, name):
        """ Get the xform-to-global either from the nif or the reference skeleton """
        if self._handle:
            buf = TransformBuf()
            buf.set_identity()
            if nifly.getNodeTransformToGlobal(self._handle, name.encode('utf-8'), buf):
                return buf
        else:
            return self.nodes[name].global_transform.copy()

        if self.reference_skel:
            nifly.getNodeTransformToGlobal(self.reference_skel._handle, 
                                                   name.encode('utf-8'), 
                                                   buf)
        return buf


    @property
    def cloth_data(self):
        """Get cloth extra data as list of (name, binary_data) tuples"""
        if self._clothdata is None:
            self._clothdata = []
            if not self._handle: 
                return self._clothdata

            # Find all cloth extra data using the direct C API
            namelen = c_int()
            valuelen = c_int()

            for i in range(0, 1000):
                exists = nifly.getClothExtraDataLen(self._handle, None, 
                                              i,
                                              byref(namelen),
                                              byref(valuelen))
                if not exists:
                    break

                name = (c_char * (namelen.value+1))()
                val = (c_char * (valuelen.value+1))()
                       
                nifly.getClothExtraData(self._handle, None,
                                 i,
                                 name, namelen.value+1,
                                 val, valuelen.value+1)
                        
                self._clothdata.append((name.value.decode('utf-8'), val.raw))
        
        return self._clothdata

    @cloth_data.setter
    def cloth_data(self, val):
        """Set cloth extra data from list of (name, binary_data) tuples"""
        self._clothdata = val
        # Write cloth extra data using the direct C API
        for s in val:
            nifly.setClothExtraData(self._handle, None, 
                                           s[0].encode('utf-8'), s[1], len(s[1])-1)


    @property
    def connect_points_parent(self):
        """Reads a nif's parent connect points as a list of ConnectPointBuf
        Name and parent name limited to 256 characters
        """
        if not self._connect_pt_par:
            self._connect_pt_par = []
            if self._handle and isinstance(self.rootNode, NiNode):
                cnt = nifly.getConnectPointParentCount(self._handle)
                if cnt:
                    bufs = (ConnectPointBuf * cnt)()
                    cnt = nifly.getConnectPointParents(self._handle, cnt, bufs)
                    self._connect_pt_par = list(bufs[0:cnt])
        return self._connect_pt_par

    @connect_points_parent.setter
    def connect_points_parent(self, value):
        bufs = (ConnectPointBuf * len(value))()
        for i, v in enumerate(value):
            bufs[i] = v
        nifly.setConnectPointsParent(self._handle, len(value), bufs)

    @property
    def connect_points_child(self):
        """Reads a nif's child connect point names as [name, name, ...].
        Sets connect_pt_child_skinned as a side effect."""
        if not self._connect_pt_child:
            self._connect_pt_child = []
            if self._handle and isinstance(self.rootNode, NiNode):
                buflen = nifly.getConnectPointChildLen(self._handle)
                if buflen:
                    buf = (c_char * buflen)()
                    v = nifly.getConnectPointChildren(self._handle, buflen, buf)
                    if v:
                        self.connect_pt_child_skinned = (v > 0)
                        self._connect_pt_child = [
                            n.decode('utf-8') for n in buf.raw.split(b'\0')[0:-1]]
        return self._connect_pt_child

    @connect_points_child.setter
    def connect_points_child(self, value):
        buf = create_string_buffer(('\0'.join(value)).encode())
        nifly.setConnectPointsChild(self._handle, self.connect_pt_child_skinned, len(buf), buf)


    @property
    def controller_managers(self):
        cm_count = nifly.findNodesByType(self._handle, self.root, 
                                                 "NiControllerManager".encode('utf-8'), 
                                                 0, None)
        cmrefs = (c_void_p * cm_count)()
        nifly.findNodesByType(self._handle, self.root, 
                                      "NiControllerManager".encode('utf-8'), 
                                      cm_count, cmrefs)
        v = []
        for i in range(0, cm_count):
            v.append(NiControllerManager(
                file=self, handle=cmrefs[i], parent=self.root))
        return v

    @staticmethod
    def clear_log():
        nifly.clearMessageLog()

    @staticmethod
    def message_log():
        msgsize = nifly.getMessageLog(None, 0)+2
        buf = create_string_buffer(msgsize)
        nifly.getMessageLog(buf, msgsize)
        return buf.value.decode('utf-8')

    def read_node(self, id=None, handle=None, properties=None, parent=None):
        """
        Return a node object for the given node ID. The node might be anything, so use the
        block name to determine what kind of object to create. 
        """
        if id is None:
            id = nifly.getBlockID(self._handle, handle)
        if id in self.node_ids:
            return self.node_ids[id]

        buf = (c_char * (self.max_string_len))()
        check_msg(nifly.getBlockname, self._handle, id, buf, self.max_string_len)
        bn = buf.value.decode('utf-8')
        if bn == "BSConnectPoint::Parents": bn = "BSConnectPointParents"
        if bn == "BSConnectPoint::Children": bn = "BSConnectPointChildren"
        if bn in NiObject.block_types:
            node = NiObject.block_types[bn](
                id=id, file=self, handle=handle, properties=properties, parent=parent)
            self.node_ids[id] = node
            try:
                if hasattr(node, 'name') and node.name and isinstance(node, NiNode): 
                    self._nodes[node.name] = node
            except:
                pass
            return node
        else:
            # Starfield skin blocks are consumed internally (bone names via GetShapeBoneList,
            # per-vertex weights from the loaded .mesh) and have no Blender representation.
            if bn not in ("SkinAttach", "BSSkin::Instance", "BSSkin::BoneData"):
                log.warning(f"Unknown block type: {bn}")
            return None


    def add_shape(self, properties, parent=None, vertices=None, normals=None, transform=None):
        """ Create collision shape in the Nif file. It can be connected to a body later.
            bhkConvexVerticesShape - vertices can be vectors of 3 points. Normals must be 
                vectors of 4 elements: x, y, z (setting direction), and w (length)
        """
        if properties.bufType == PynBufferTypes.bhkConvexTransformShapeBufType:
            if transform:
                for r in range(0,4):
                    for c in range(0,4):
                        properties.transform[c][r] = transform[r][c]

        collshape_index = nifly.addBlock(
            self._handle, None, byref(properties), 
            parent.id if parent else NODEID_NONE)
        new_collshape = bhkShape.New(
            id=collshape_index, file=self, properties=properties, parent=parent)
        
        if properties.bufType == PynBufferTypes.bhkConvexVerticesShapeBufType:
            vertbuf = (VECTOR4 * len(vertices))()
            normbuf = (VECTOR4 * len(normals))()
            for i, v in enumerate(vertices):
                vertbuf[i] = (v[0], v[1], v[2], 0)
            for i, n in enumerate(normals):
                normbuf[i][0], normbuf[i][1], normbuf[i][2], normbuf[i][3] = n[:]

            nifly.setCollConvexVerts(
                self._handle, collshape_index,
                vertbuf, len(vertices), normbuf, len(normals))
        
        return new_collshape


class hkxSkeletonFile(NifFile):
    """
    Represents a hkx skeleton file. Extends and replaces NifFile's functionality to
    read a XML file instead of a nif. 
    """
    has_extra_data = False

    def __init__(self, filepath=None):
        super().__init__(filepath=None)
        self.filepath = filepath
        self.xmlfile = None
        self.xmlroot = None
        self._game = "SKYRIM"
        self.dict = gameSkeletons[self._game]
        if filepath: 
            self.load_from_file()


    @property
    def name(self):
        if self.filepath:
            return Path(self.filepath).stem
        else:
            return "None"
        

    def load_from_file(self):
        """
        Load the skeleton from a HKX or XML file. Since the XML spreads bone information
        across multiple constructs it's more convenient to load it all at once.
        """
        if self.xmlroot:
            # Prevent recursive call from NiNode().
            return
        
        if os.path.splitext(self.filepath)[1].upper() == ".HKX":
            self.xml_filepath = xmltools.XMLFile.hkx_to_xml(Path(self.filepath))
        else:
            self.xml_filepath = self.filepath
    
        self.xmlfile = xml.parse(self.xml_filepath)
        self.xmlroot = self.xmlfile.getroot()

        skel = self.xmlroot.find(".//*[@class='hkaSkeleton']")
        skelname = skel.find("./*[@name='name']").text
        parentIndices = [int(x) for x in skel.find("./*[@name='parentIndices']").text.split()]

        bonelist = []
        skelbones = skel.find("./*[@name='bones']")
        for b in skelbones.iter('hkobject'):
            bonelist.append(b.find("./*[@name='name']").text)

        pose = skel.find("./*[@name='referencePose']")
        poselist = pose.text.strip(' ()\t\n').split(')')

        mxWorld = [None] * len(bonelist)
        i = j = 0
        while i < len(poselist) and j < len(bonelist):
            parent = None
            parentname = None
            if parentIndices[j] >= 0:
                parentname = bonelist[parentIndices[j]]
                if parentname in self.nodes:
                    parent = self.nodes[parentname]

            loc = rot = None
            loclist = poselist[i].strip(' ()\t\n').split()
            if len(loclist) == 3:
                loc = [float(x) for x in loclist]
            else:
                self.warn(f"Pose list does not have translation at index {j}: {poselist[i]}")

            rotlist = poselist[i+1].strip(' ()\t\n').split()
            if len(rotlist) == 4:
                # Note this quaternion may not be normalized
                rot = PM.quaternion_to_matrix(
                    [float(rotlist[3]), float(rotlist[0]), float(rotlist[1]), float(rotlist[2])])
            else:
                self.warn(f"Pose list does not have good rotation at index {j}: {poselist[i+1]}")

            scalelist = poselist[i+2].strip(' ()\t\n').split()
            if len(scalelist) == 3:
                scale = [float(x) for x in scalelist]
            else:
                self.warn(f"Pose list does not have good scale at index {j}: {poselist[i+2]}")
            
            if loc and rot and scale:
                buf = NiNodeBuf()
                buf.transform.translation = VECTOR3(*loc)
                buf.transform.rotation = MATRIX3(VECTOR3(*rot[0]), VECTOR3(*rot[1]), VECTOR3(*rot[2]))
                buf.transform.scale = scale[0]
                n = NiNode(file=self, parent=parent,
                           properties=buf, name=bonelist[j])
                # The skeleton's own root bone (bone 0, no parent) is the file
                # root: giving it id 0 makes register_node record it as _root.
                n.id = j
                n._blockname = "NiNode"
                self.register_node(n)

            i += 3
            j += 1
        
        
    @property
    def nodes(self):
        """Overwrites "nodes" property to get them from the XML file, not a nif file."""
        if self._nodes is None:
            self._nodes = {}
            self.load_from_file()
        return self._nodes

NiObject.register_subclasses()
